"""
AnimaSpace Physics Simulator
=============================

A comprehensive, fully-traceable physics simulation framework for the AnimaSpace
microgravity bio-manufacturing platform.

This package models the complete pipeline:
  1. Cell intake and processing (WRM - Warming & Reanimation Machine)
  2. Acoustic droplet formation and transport (gas-phase logistics)
  3. Bio-reactor culture (liquid-phase proliferation)
  4. Precision deposition (water-phase tissue assembly)

Core Subsystems
---------------
- acoustic: Transducer arrays, pressure fields, acoustic streaming
- fluids: Stokes drag, Reynolds numbers, droplet dynamics
- droplet: Formation mechanics, surface tension, nucleation
- transit: Movement through gas and liquid media
- assembly: Tissue construction sequencing and coordination

Usage
-----
>>> from animaspace_simulator import AcousticTransducer, StokesFluid, DropletFormation
>>> from animaspace_simulator import TransitSimulator, TissueAssembly

# Instantiate subsystems with documented parameters
transducer = AcousticTransducer(frequency_hz=1e6, power_w=1.0)
fluid = StokesFluid(medium='air', temperature_c=25)
droplet = DropletFormation(fluid=fluid, cell_diameter_um=15)

# Run integrated simulation
simulator = TransitSimulator(transducer, fluid, droplet)
trajectory = simulator.run_gas_phase_transit(distance_m=0.1)

Design Philosophy
-----------------
Every calculation is:
  - Mathematically explicit (equations in docstrings)
  - Traceable (logging at each step)
  - Parametric (all assumptions exposed as variables)
  - Validated against physical literature
  - Modular (swap fluid, transducer, or cell properties easily)

References
----------
- Andrade, E.N.C. (1933): Acoustic streaming
- Nyborg, W.L. (1958): Acoustic radiation pressure
- Bruus, H. (2012): Acoustofluidics fundamentals
- King, L.V. (1934): Acoustic radiation forces
- NASA DECLIC experiments: Toroidal drop formations in microgravity

Author: James Brake (jbrake1)
License: MIT
"""

__version__ = "0.1.0"

from .core_physics import (
    PhysicsConstants,
    MediumProperties,
    CellProperties,
)

from .acoustic import (
    AcousticTransducer,
    PMUTArray,
    AcousticRadiationPressure,
    AcousticStreaming,
)

from .fluids import (
    StokesFluid,
    DragCalculator,
    ReynoldsNumber,
)

from .droplet import (
    DropletFormation,
    SurfaceTension,
    LaplacePressure,
    DropletNucleation,
)

from .transit import (
    TransitSimulator,
    GasPhaseTransit,
    LiquidPhaseTransit,
)

from .assembly import (
    TissueAssembly,
    DepositonUnitCoordinator,
    BioReactorInterface,
)

__all__ = [
    # Core
    "PhysicsConstants",
    "MediumProperties",
    "CellProperties",
    # Acoustic
    "AcousticTransducer",
    "PMUTArray",
    "AcousticRadiationPressure",
    "AcousticStreaming",
    # Fluids
    "StokesFluid",
    "DragCalculator",
    "ReynoldsNumber",
    # Droplets
    "DropletFormation",
    "SurfaceTension",
    "LaplacePressure",
    "DropletNucleation",
    # Transit
    "TransitSimulator",
    "GasPhaseTransit",
    "LiquidPhaseTransit",
    # Assembly
    "TissueAssembly",
    "DepositonUnitCoordinator",
    "BioReactorInterface",
]
