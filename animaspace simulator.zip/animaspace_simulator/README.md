# AnimaSpace Physics Simulator

**A comprehensive, fully-traceable physics simulation framework for the AnimaSpace microgravity bio-manufacturing platform.**

## Overview

This Python package models the complete AnimaSpace pipeline with explicit mathematical detail:

```
WRM (Intake)
    ↓ [Acoustic droplet formation, cell encapsulation]
    ↓ Gas Phase Transit (~1-100 m/s, milliseconds)
Bio-Reactor (Culture)
    ↓ [Cell proliferation, differentiation]
    ↓ Liquid Phase Transit (~0.01-1 m/s, seconds)
Deposition Unit (Assembly)
    ↓ [Layer-by-layer tissue construction]
Finished Tissue
```

## Design Philosophy

Every calculation is:
- **Mathematically explicit** – Equations visible in docstrings
- **Traceable** – Logging at each computational step
- **Parametric** – All assumptions exposed as tunable variables
- **Validated** – References to peer-reviewed literature
- **Modular** – Swap components (fluid, transducer, cell type) easily

## Package Structure

```
animaspace_simulator/
├── __init__.py                 # Package entry point
├── core_physics.py             # Physical constants, material properties
├── acoustic.py                 # Transducers, radiation pressure, streaming
├── fluids.py                   # Drag forces, Reynolds numbers, Stokes flow
├── droplet.py                  # Droplet formation, surface tension, Laplace pressure
├── transit.py                  # Gas and liquid phase transit simulation
├── assembly.py                 # Tissue assembly, deposition coordination
├── example_usage.py            # 10 comprehensive worked examples
└── README.md                   # This file
```

## Core Modules

### `core_physics.py`
Fundamental constants and material properties.

**Key classes:**
- `PhysicsConstants` – Universal constants (Boltzmann, sound speed, etc.)
- `MediumProperties` – Fluid properties (viscosity, density, surface tension) with temperature dependence
- `CellProperties` – Biological cell parameters (size, density, acoustic contrast)

**Features:**
- Temperature-dependent viscosity (Sutherland formula for air, empirical for water)
- Sound speed calculations (Medwin formula for water)
- Surface tension temperature dependence
- Acoustic contrast factor (for radiation force calculation)

### `acoustic.py`
Acoustic transducers and field calculations.

**Key classes:**
- `AcousticTransducer` – Single PMUT element with frequency, power, positioning
- `PMUTArray` – Phased array of transducers with steering patterns
- `AcousticRadiationPressure` – Radiation pressure and forces
- `AcousticStreaming` – Bulk fluid motion, vortex formation

**Calculations:**
- Acoustic intensity (I = P²/(2ρc))
- Radiation pressure (P_rad = I/c)
- Wavelength and far-field pressure
- Gor'kov potential (particle trapping)
- Acoustic streaming velocity

### `fluids.py`
Fluid dynamics in Stokes (viscous-dominated) flow regime.

**Key classes:**
- `ReynoldsNumber` – Regime classification and drag law selection
- `DragCalculator` – Stokes drag, Oseen correction, intermediate/Newton drag
- `StokesFluid` – Wrapper with convenience methods

**Calculations:**
- Stokes drag (F = 6πηrv)
- Terminal velocity under acoustic or gravitational forces
- Drag force with automatic regime detection (Re < 0.1 → Stokes, etc.)
- Power dissipation (P = F·v)
- Relaxation time constants

### `droplet.py`
Droplet formation and surface tension effects.

**Key classes:**
- `SurfaceTension` – Air-water interface properties with temperature dependence
- `LaplacePressure` – Pressure jump across curved interface (ΔP = 2σ/r)
- `DropletFormation` – Nucleation, atomization, cell encapsulation
- `DropletNucleation` – Energy barriers, cavitation

**Calculations:**
- Laplace pressure (sphere, cylinder, torus)
- Ideal droplet size for single-cell encapsulation
- Surface energy and Helmholtz free energy
- Capillary number (force balance)
- Nucleation energy barrier

### `transit.py`
Droplet trajectory simulation through gas and liquid phases.

**Key classes:**
- `TransitTrajectory` – Records position, velocity, forces at each time step
- `GasPhaseTransit` – WRM → Bio-reactor (fast, ~milliseconds)
- `LiquidPhaseTransit` – Bio-reactor → Deposition (controlled, ~seconds)
- `TransitSimulator` – Coordinates full pipeline

**Simulations:**
- Equation of motion: m·dv/dt = F_acoustic - F_drag
- Automatic time-stepping with convergence checking
- Reynolds number tracking
- Trajectory logging and statistics

### `assembly.py`
Tissue structure and deposition coordination (framework for expansion).

**Key classes:**
- `CellDeposition` – Individual cell placement record (position, timing, viability)
- `TissueAssembly` – Tissue blueprint with build schedule
- `DepositonUnitCoordinator` – Deposition nozzle control (stub)
- `BioReactorInterface` – Reactor intake/harvest logic (stub)

## Key Physics Equations

### Stokes Drag (Low Reynolds Regime)
```
F_drag = 6πηrv

Where:
  η = dynamic viscosity (Pa·s)
  r = particle radius (m)
  v = velocity (m/s)
  F = force (N)
```

### Acoustic Intensity and Radiation Pressure
```
I = P²/(2ρc)          [Acoustic intensity, W/m²]
P_rad = I/c = P²/(2ρc²)  [Radiation pressure, Pa]

Where:
  P = acoustic pressure amplitude (Pa)
  ρ = medium density (kg/m³)
  c = sound speed (m/s)
```

### Laplace Pressure (Spherical Droplet)
```
ΔP = 2σ/r

Where:
  σ = surface tension (N/m)
  r = droplet radius (m)
  ΔP = pressure jump inside/outside (Pa)
```

### Reynolds Number (Flow Regime Classification)
```
Re = (ρ·v·L) / η

Re << 0.1:  Creeping flow, Stokes drag applies exactly
0.1 < Re < 1:  Transitional, Oseen correction needed
1 < Re < 1000:  Intermediate, empirical drag coefficient
Re >> 1000: Newton drag (F ∝ v²)
```

### Terminal Velocity (Acoustic Driving)
```
At equilibrium: F_acoustic = F_drag = 6πηrv_t

Therefore: v_t = F_acoustic / (6πηr)

In AnimaSpace: Typical velocities are 0.01-10 m/s (depending on medium)
```

### Toroidal Vortex Formation
```
Toroid radius ≈ λ = c/f

Where:
  c = sound speed (m/s)
  f = transducer frequency (Hz)

Example: 1 MHz in water → λ ≈ 1.5 mm
```

## Usage Examples

### Example 1: Calculate drag force on a cell

```python
from animaspace_simulator import (
    create_water_20c,
    create_generic_mammalian_cell,
)
from animaspace_simulator.fluids import DragCalculator

water = create_water_20c()
cell = create_generic_mammalian_cell()

velocity_m_s = 0.1
F_drag, metadata = DragCalculator.total_drag(cell.radius_m, velocity_m_s, water)

print(f"Reynolds number: {metadata['Re']:.3e}")
print(f"Regime: {metadata['regime']}")
print(f"Drag force: {F_drag:.3e} N")
```

### Example 2: Acoustic radiation pressure

```python
from animaspace_simulator import (
    AcousticTransducer,
    create_water_20c,
)
from animaspace_simulator.acoustic import AcousticRadiationPressure

water = create_water_20c()
transducer = AcousticTransducer(frequency_hz=1e6, power_w=1.0)

P_peak = transducer.peak_pressure(water)
P_rad = AcousticRadiationPressure.radiation_pressure_from_pressure(P_peak, water)

print(f"Peak acoustic pressure: {P_peak:.2e} Pa")
print(f"Radiation pressure: {P_rad:.2e} Pa")
```

### Example 3: Gas-phase transit simulation

```python
from animaspace_simulator import (
    AcousticTransducer,
    create_air_20c,
    create_water_20c,
    create_generic_mammalian_cell,
)
from animaspace_simulator.droplet import DropletFormation
from animaspace_simulator.transit import GasPhaseTransit

air = create_air_20c()
water = create_water_20c()
cell = create_generic_mammalian_cell()

droplet = DropletFormation(water, cell)
transducer = AcousticTransducer(frequency_hz=1e6, power_w=1.0)

gas_transit = GasPhaseTransit(droplet, air, transducer)

# Simulate 0.1 m transit
start = (0.0, 0.0, 0.0)
end = (0.1, 0.0, 0.0)
droplet_radius_m = 100e-6

trajectory = gas_transit.simulate_trajectory(start, end, droplet_radius_m)

print(f"Transit time: {trajectory.time_total_s:.3e} s")
print(f"Average speed: {trajectory.distance_total_m/trajectory.time_total_s:.3f} m/s")
```

### Example 4: Full pipeline simulation

```python
from animaspace_simulator import (
    create_air_20c, create_culture_medium_37c,
    create_linear_array_1d,
    AcousticTransducer,
)
from animaspace_simulator.transit import TransitSimulator

air = create_air_20c()
medium = create_culture_medium_37c()

transducer_gas = AcousticTransducer(frequency_hz=1e6, power_w=1.0)
array_liquid = create_linear_array_1d(num_elements=8, frequency_hz=1e6)

simulator = TransitSimulator(transducer_gas, array_liquid, air, medium)

result = simulator.simulate_full_pipeline(
    wrm_position_m=(0.0, 0.0, 0.0),
    bioreactor_position_m=(0.1, 0.0, 0.0),
    deposition_position_m=(0.1, 0.05, 0.0),
    droplet_radius_m=100e-6,
)

print(f"Total time: {result['total_time_s']:.3e} s")
print(f"Gas phase speed: {result['gas_avg_speed_m_s']:.3f} m/s")
print(f"Liquid phase speed: {result['liquid_avg_speed_m_s']:.3f} m/s")
```

## Running Examples

To see all 10 worked examples with full output:

```bash
python -m animaspace_simulator.example_usage
```

This will print comprehensive traces of:
1. Physical constants
2. Cell properties and acoustic contrast
3. Acoustic transducers and fields
4. Phased array beam steering
5. Radiation pressure and forces
6. Acoustic streaming and vortices
7. Drag forces and Reynolds regimes
8. Droplet formation and surface tension
9. Gas-phase transit simulation
10. Tissue assembly and scheduling

## References

- **Andrade, E.N.C. (1933)** – "The viscous flow in acoustic fields," Physical Review 44, 476-480.
- **Bruus, H. (2012)** – "Acoustofluidics fundamentals and applications," Journal of Micromechanics and Microengineering 22, 063001.
- **King, L.V. (1934)** – "On the acoustic radiation pressure on spheres," Proceedings of the Royal Society A 147, 212-240.
- **Nyborg, W.L. (1958)** – "Acoustic streaming near a boundary," Journal of the Acoustical Society of America 30, 329-339.
- **NASA DECLIC** – Drop tower and ISS experiments documenting toroidal droplet formations in microgravity.

## Architecture Notes

### Why Stokes Flow?
AnimaSpace operates at Reynolds numbers Re < 1 (typically 0.01 - 0.5), where viscous forces dominate inertial forces. This means:
- Drag is directly proportional to velocity (not velocity-squared)
- Particles reach terminal velocity almost instantly
- Trajectory is deterministic (no turbulence)

### Gas vs. Liquid Phase Design
The choice of gas for rapid transit (~milliseconds) and liquid for controlled deposition (~seconds) reflects the physics:
- **Gas:** ~1000× lower viscosity → terminal velocity ∝ F_acoustic/η is 1000× higher
- **Liquid:** High viscosity enables precise control via phased-array beam steering

### Microgravity Advantage
In zero gravity (g ≈ 0), gravitational settling is eliminated, and acoustic radiation pressure becomes the dominant force. This enables:
- 3D positioning (not just vertical control)
- Stable toroidal vortices (NASA DECLIC confirmation)
- Precise droplet movement without convection

## Future Expansion

Current placeholder stubs ready for development:

1. **BioReactorInterface** – Nutrient delivery algorithms, oxygen control, temperature regulation
2. **DepositonUnitCoordinator** – Multi-nozzle control, layer-stacking logic
3. **TissueAssembly** – Build file format, vascularization patterns, mechanical properties
4. **VialityAssessment** – Pre-deposition QC (optical/acoustic sensing models)
5. **ParameterOptimization** – Automated tuning of transducer power, frequency, geometry

## License

MIT License – See LICENSE file.

## Author

James Brake (jbrake1) – AnimaSpace project lead

## Citation

If using this simulator in research or publications:

```
@software{AnimaSpaceSimulator2024,
  title={AnimaSpace Physics Simulator: Fully-Traceable Calculations for Microgravity Bio-Manufacturing},
  author={Brake, James},
  year={2024},
  url={https://github.com/jbrake1/animaSpace}
}
```

---

**AnimaSpace: Engineering the Future of Regenerative Medicine in Space**
