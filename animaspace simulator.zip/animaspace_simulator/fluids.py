"""
Fluid Dynamics and Drag Calculations
====================================

Covers Stokes drag, Reynolds number, drag coefficients, and motion
in Stokes flow (viscous-dominated) regimes.

AnimaSpace operates in low Reynolds number (Stokes) regime:
  - Cells/droplets: Re ~ 0.01 - 1
  - Viscous forces dominate inertial forces
  - Linear momentum balance: F_acoustic + F_drag = 0 (steady state)

Key equations:
  - Stokes drag: F_drag = 6πηrv (sphere)
  - Reynolds number: Re = ρvL/η
  - Terminal velocity: v_t = F/(6πηr)
  - Power dissipation: P_diss = F·v

References:
  - Landau & Lifshitz (1987): "Fluid Mechanics"
  - Happel & Brenner (1983): "Low Reynolds Number Hydrodynamics"
  - Bruus, H. (2012): "Acoustofluidics fundamentals"
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional
import logging

from .core_physics import PhysicsConstants, MediumProperties, CellProperties

logger = logging.getLogger(__name__)


@dataclass
class ReynoldsNumber:
    """
    Reynolds number and regime classification.
    
    Re = (ρ·v·L) / η
    
    Regime boundaries:
      Re << 0.1: Creeping flow (Stokes flow)
      0.1 < Re < 1: Transitional
      Re > 1: Inertial (drag ∝ v²)
    """
    
    reynolds_number: float
    
    def regime(self) -> str:
        """Classify flow regime."""
        if self.reynolds_number < 0.01:
            return "Creeping (Stokes flow)"
        elif self.reynolds_number < 0.1:
            return "Low Reynolds (Stokes-valid)"
        elif self.reynolds_number < 1:
            return "Transitional (Stokes corrections needed)"
        elif self.reynolds_number < 1000:
            return "Moderate Reynolds"
        else:
            return "High Reynolds (turbulent possible)"
    
    def drag_law(self) -> str:
        """Return which drag law applies."""
        if self.reynolds_number < 0.1:
            return "Stokes: F_drag ∝ v"
        elif self.reynolds_number < 1000:
            return "Intermediate: F_drag ∝ v^n, n ∈ (1, 2)"
        else:
            return "Newton: F_drag ∝ v²"
    
    def stokes_correction_factor(self) -> float:
        """
        Oseen correction factor for Stokes drag at moderate Re.
        
        Stokes formula F = 6πηrv is exact for Re → 0.
        Oseen (1927) provides correction:
        F = 6πηrv · (1 + 3Re/8 + 9Re²/160 + ...)
        
        For Re < 1, this is a small correction.
        """
        Re = self.reynolds_number
        if Re < 0.01:
            return 1.0
        
        # Oseen series (truncated)
        correction = 1.0 + (3.0/8.0)*Re + (9.0/160.0)*Re**2
        return correction
    
    def __str__(self) -> str:
        return f"Re = {self.reynolds_number:.3e}, Regime: {self.regime()}, Law: {self.drag_law()}"


class DragCalculator:
    """
    Comprehensive drag force calculator for spherical particles.
    
    Handles:
      - Stokes drag (Re < 0.1)
      - Oseen correction (0.1 < Re < 1)
      - Intermediate drag (1 < Re < 1000)
      - Newton drag (Re > 1000)
    """
    
    @staticmethod
    def stokes_drag(radius_m: float,
                   velocity_m_s: float,
                   medium: MediumProperties) -> float:
        """
        Stokes drag for a sphere in viscous flow.
        
        Equation: F_drag = 6πηrv
        
        Where:
          η = dynamic viscosity (Pa·s)
          r = particle radius (m)
          v = velocity (m/s)
        
        Valid for: Re < 0.1 (typically satisfied in AnimaSpace)
        Returns: Force in Newtons
        
        Physical interpretation:
          - Directly proportional to viscosity (thick fluid → more drag)
          - Directly proportional to size (larger particle → more drag)
          - Directly proportional to velocity (faster → more drag)
        """
        F_drag = 6.0 * np.pi * medium.dynamic_viscosity_pa_s * radius_m * velocity_m_s
        
        return F_drag
    
    @staticmethod
    def drag_with_oseen_correction(radius_m: float,
                                   velocity_m_s: float,
                                   medium: MediumProperties) -> Tuple[float, float, float]:
        """
        Stokes drag with Oseen correction for moderate Reynolds numbers.
        
        Returns: (F_drag, Re, correction_factor)
        
        Oseen correction = 1 + (3/8)Re + (9/160)Re²
        
        Applicable for: 0.01 < Re < 1
        """
        F_stokes = DragCalculator.stokes_drag(radius_m, velocity_m_s, medium)
        
        # Calculate Reynolds number
        characteristic_length = 2.0 * radius_m  # Diameter
        Re = medium.reynolds_number(velocity_m_s, characteristic_length)
        
        # Oseen correction
        re_obj = ReynoldsNumber(Re)
        correction = re_obj.stokes_correction_factor()
        
        F_drag = F_stokes * correction
        
        return F_drag, Re, correction
    
    @staticmethod
    def intermediate_drag_law(radius_m: float,
                             velocity_m_s: float,
                             medium: MediumProperties) -> Tuple[float, float]:
        """
        Intermediate drag law for 1 < Re < 1000.
        
        Empirical fit: C_d ≈ (24/Re) · (1 + 0.15·Re^0.687)
        
        Drag coefficient C_d defined as:
        F_drag = (1/2) · ρ · v² · A · C_d
        
        Where A = πr² (cross-sectional area)
        
        Returns: (F_drag, C_d)
        """
        characteristic_length = 2.0 * radius_m
        Re = medium.reynolds_number(velocity_m_s, characteristic_length)
        
        # Empirical coefficient (Clift & Gauvin, 1971)
        if Re < 1e-3:
            C_d = 24.0 / Re if Re > 0 else np.inf
        else:
            C_d = (24.0 / Re) * (1.0 + 0.15 * Re**0.687)
        
        # Drag force
        A = np.pi * radius_m**2
        F_drag = 0.5 * medium.density_kg_m3 * velocity_m_s**2 * A * C_d
        
        return F_drag, C_d
    
    @staticmethod
    def newton_drag(radius_m: float,
                   velocity_m_s: float,
                   medium: MediumProperties,
                   C_d_sphere: float = 0.47) -> float:
        """
        Newton drag law (inertia-dominated, Re >> 1).
        
        Equation: F_drag = (1/2) · ρ · v² · A · C_d
        
        Where:
          ρ = fluid density (kg/m³)
          v = velocity (m/s)
          A = cross-sectional area = πr²
          C_d = drag coefficient (~0.47 for sphere)
        
        Valid for: Re > 1000
        """
        A = np.pi * radius_m**2
        F_drag = 0.5 * medium.density_kg_m3 * velocity_m_s**2 * A * C_d_sphere
        
        return F_drag
    
    @staticmethod
    def total_drag(radius_m: float,
                   velocity_m_s: float,
                   medium: MediumProperties) -> Tuple[float, dict]:
        """
        Calculate drag force with automatic regime selection.
        
        Returns: (F_drag, metadata_dict)
        
        Metadata includes:
          - Re: Reynolds number
          - regime: Flow regime classification
          - method: Which drag law was used
          - C_d: Drag coefficient (if applicable)
        """
        metadata = {}
        
        characteristic_length = 2.0 * radius_m
        Re = medium.reynolds_number(velocity_m_s, characteristic_length)
        metadata['Re'] = Re
        metadata['velocity'] = velocity_m_s
        metadata['radius'] = radius_m
        
        # Select appropriate method based on Reynolds number
        if Re < 0.1:
            F_drag = DragCalculator.stokes_drag(radius_m, velocity_m_s, medium)
            metadata['regime'] = "Stokes (Re < 0.1)"
            metadata['method'] = "Stokes: F = 6πηrv"
            metadata['C_d'] = 24.0 / Re if Re > 1e-10 else np.inf
        
        elif Re < 1.0:
            F_drag, Re, correction = DragCalculator.drag_with_oseen_correction(
                radius_m, velocity_m_s, medium
            )
            metadata['regime'] = "Low Reynolds (0.1 ≤ Re < 1)"
            metadata['method'] = f"Stokes + Oseen (correction={correction:.3f})"
            metadata['C_d'] = 24.0 / Re * correction
        
        elif Re < 1000:
            F_drag, C_d = DragCalculator.intermediate_drag_law(
                radius_m, velocity_m_s, medium
            )
            metadata['regime'] = "Intermediate (1 ≤ Re < 1000)"
            metadata['method'] = "Empirical drag coefficient"
            metadata['C_d'] = C_d
        
        else:
            F_drag = DragCalculator.newton_drag(radius_m, velocity_m_s, medium)
            metadata['regime'] = "Newton (Re ≥ 1000)"
            metadata['method'] = "Newton: F = 0.5·ρ·v²·A·C_d"
            metadata['C_d'] = 0.47
        
        return F_drag, metadata


class StokesFluid:
    """
    Low Reynolds number fluid environment (Stokes flow).
    
    Wrapper around MediumProperties with convenience methods for
    Stokes flow calculations.
    """
    
    def __init__(self, medium: MediumProperties):
        """Initialize from a MediumProperties object."""
        self.medium = medium
        self.drag_calculator = DragCalculator()
    
    def terminal_velocity(self, particle: CellProperties, 
                         gravity_acceleration_m_s2: float = PhysicsConstants.G_EARTH) -> float:
        """
        Terminal velocity of a particle falling under gravity in Stokes flow.
        
        Balance: F_gravity = F_drag
        m·g = 6πηrv_t
        
        Solving for v_t:
        v_t = (2·r²/(9·η)) · (ρ_particle - ρ_fluid) · g
        
        In microgravity (g ≈ 0), this is negligible.
        """
        rho_eff = particle.density_kg_m3 - self.medium.density_kg_m3
        
        if rho_eff <= 0:
            return 0.0  # Particle less dense or neutral, doesn't settle
        
        v_terminal = (2.0 * particle.radius_m**2 / (9.0 * self.medium.dynamic_viscosity_pa_s)) * rho_eff * gravity_acceleration_m_s2
        
        return v_terminal
    
    def acoustic_force_terminal_velocity(self, particle: CellProperties,
                                        acoustic_force_n: float) -> float:
        """
        Terminal velocity when driven by acoustic force (not gravity).
        
        At equilibrium: F_acoustic = F_drag
        F_acoustic = 6πηrv_t
        
        Solving for v_t:
        v_t = F / (6πηr)
        """
        denominator = 6.0 * np.pi * self.medium.dynamic_viscosity_pa_s * particle.radius_m
        
        if denominator == 0:
            return np.inf
        
        v_terminal = acoustic_force_n / denominator
        
        return v_terminal
    
    def time_to_terminal_velocity(self, particle: CellProperties,
                                 force_n: float) -> float:
        """
        Time constant for particle to reach terminal velocity.
        
        In Stokes flow, equation of motion:
        m · dv/dt = F - 6πηrv
        
        Solution has time constant τ = m / (6πηr)
        
        Where m = (4/3)πr³ρ_particle
        
        Therefore: τ = (4/3)πr³ρ_particle / (6πηr) = (2r²ρ_particle) / (9η)
        
        Terminal velocity reached in ~5τ (99% steady-state)
        """
        tau = (2.0 * particle.radius_m**2 * particle.density_kg_m3) / (9.0 * self.medium.dynamic_viscosity_pa_s)
        
        return tau
    
    def drag_force(self, particle: CellProperties,
                   velocity_m_s: float) -> Tuple[float, dict]:
        """
        Calculate drag force on a particle in this fluid.
        
        Returns: (F_drag, metadata)
        """
        return self.drag_calculator.total_drag(particle.radius_m, velocity_m_s, self.medium)
    
    def power_dissipation(self, particle: CellProperties,
                         velocity_m_s: float) -> float:
        """
        Power dissipated by drag (heat generated).
        
        P_dissipated = F_drag · v
        
        This energy comes from acoustic or other driving forces.
        """
        F_drag, _ = self.drag_force(particle, velocity_m_s)
        P = F_drag * velocity_m_s
        
        return P
    
    def relaxation_length(self, particle: CellProperties,
                         velocity_m_s: float) -> float:
        """
        Distance traveled before particle reaches terminal velocity.
        
        Relaxation length: x_relax = v_0 · τ
        
        Where τ = time constant = (2r²ρ_particle) / (9η)
        """
        tau = self.time_to_terminal_velocity(particle, force_n=1.0)  # Dummy force
        x_relax = velocity_m_s * tau
        
        return x_relax
    
    def __str__(self) -> str:
        """Human-readable summary."""
        return f"StokesFluid: {self.medium.name}\n{str(self.medium)}"
