"""
Droplet Formation and Surface Tension
=====================================

Covers droplet nucleation, surface tension, Laplace pressure, and
the mechanics of creating single-cell droplets at the WRM intake stage.

Key concepts:
  - Laplace pressure: ΔP = 2σ/r (pressure jump across curved interface)
  - Droplet size stability: Smaller droplets need higher internal pressure
  - Nucleation: Formation of droplet from bulk liquid or captured bubble
  - Cell encapsulation: Acoustic field + streaming positions cells at surface
    before droplet separation

References:
  - Young-Laplace equation: ΔP = 2σ/r
  - Plateau-Rayleigh instability: Breakup of liquid columns
  - Tate's law: Weight of falling droplet
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional
import logging

from .core_physics import PhysicsConstants, MediumProperties, CellProperties

logger = logging.getLogger(__name__)


class SurfaceTension:
    """
    Surface tension and interfacial properties.
    
    Surface tension σ (N/m = kg/s²) is the energy per unit area at an interface.
    
    Physical origin: Molecules at interface experience unbalanced intermolecular forces.
    This creates an effective "elastic membrane" that resists deformation.
    
    Common values (at 20°C):
      - Air-water: σ ≈ 0.0728 N/m
      - Air-culture medium: σ ≈ 0.070 N/m (slightly reduced due to salts/proteins)
      - Oil-water: σ ≈ 0.027 N/m
    
    Temperature dependence: σ decreases with temperature (roughly linear)
    """
    
    @staticmethod
    def water_air_surface_tension(temperature_c: float = 20.0) -> float:
        """
        Surface tension of water at air interface.
        
        Empirical formula (valid 0-40°C):
        σ(T) = σ₀ - α·T
        
        Where:
          σ₀ = 0.0728 N/m (at 20°C)
          α ≈ 0.0001 N/(m·K)
        
        Better fit (NIST):
        σ(T) = a·(1 - T/T_c)^n
        """
        # Simple linear approximation
        sigma_0 = 0.0728  # N/m at 20°C
        alpha = 0.0001    # N/(m·K) temperature coefficient
        
        sigma = sigma_0 - alpha * (temperature_c - 20.0)
        
        return sigma
    
    @staticmethod
    def interfacial_tension_medium_air(temperature_c: float = 20.0) -> float:
        """
        Surface tension of culture medium at air interface.
        
        Culture media typically contain:
          - Salts (osmolyte)
          - Proteins (serum, albumin)
          - pH buffers
        
        These reduce surface tension compared to pure water by ~5-10%.
        """
        sigma_water = SurfaceTension.water_air_surface_tension(temperature_c)
        
        # Reduction factor due to dissolved solutes
        reduction = 0.95
        
        return sigma_water * reduction


class LaplacePressure:
    """
    Laplace pressure: Pressure jump across curved interface.
    
    Young-Laplace equation:
    ΔP = P_inside - P_outside = 2σ/r
    
    For sphere: ΔP = 2σ/r
    For torus (toroidal droplet in vortex): ΔP depends on major/minor radii
    
    Physical meaning: Curved interfaces create pressure differences.
    Smaller droplets have higher internal pressure.
    """
    
    @staticmethod
    def pressure_jump_sphere(radius_m: float,
                            surface_tension_n_m: float) -> float:
        """
        Laplace pressure for a spherical droplet.
        
        Equation: ΔP = 2σ/r
        
        Where:
          σ = surface tension (N/m)
          r = droplet radius (m)
          ΔP = pressure jump (Pa)
        
        Example:
          For r = 100 μm, σ = 0.073 N/m:
          ΔP = 2 × 0.073 / 1e-4 = 1460 Pa ≈ 0.014 atm
        """
        if radius_m <= 0:
            raise ValueError("Radius must be positive")
        
        delta_p = 2.0 * surface_tension_n_m / radius_m
        
        return delta_p
    
    @staticmethod
    def pressure_jump_cylinder(radius_m: float,
                              surface_tension_n_m: float) -> float:
        """
        Laplace pressure for a cylindrical interface.
        
        For a cylinder: ΔP = σ/r
        
        Less relevant for AnimaSpace, but included for completeness.
        """
        delta_p = surface_tension_n_m / radius_m
        return delta_p
    
    @staticmethod
    def pressure_jump_toroid(major_radius_m: float,
                            minor_radius_m: float,
                            surface_tension_n_m: float) -> Tuple[float, float]:
        """
        Laplace pressure for a toroidal droplet.
        
        A toroid (doughnut shape) has two principal radii:
          - Major radius R: distance from center to tube axis
          - Minor radius r: radius of the tube
        
        Pressure jumps:
          ΔP_minor = 2σ/r (across minor radius)
          ΔP_major = 2σ/R (across major radius)
        
        For stability, both should be non-negative.
        
        Returns: (ΔP_minor, ΔP_major)
        """
        delta_p_minor = 2.0 * surface_tension_n_m / minor_radius_m if minor_radius_m > 0 else np.inf
        delta_p_major = 2.0 * surface_tension_n_m / major_radius_m if major_radius_m > 0 else np.inf
        
        return delta_p_minor, delta_p_major
    
    @staticmethod
    def droplet_internal_pressure(radius_m: float,
                                 surface_tension_n_m: float,
                                 external_pressure_pa: float = 101325.0) -> float:
        """
        Absolute internal pressure of a droplet.
        
        P_internal = P_external + ΔP_Laplace
        
        Where:
          P_external = surrounding fluid pressure (Pa)
          ΔP_Laplace = 2σ/r (pressure jump)
        """
        delta_p = LaplacePressure.pressure_jump_sphere(radius_m, surface_tension_n_m)
        p_internal = external_pressure_pa + delta_p
        
        return p_internal


class DropletFormation:
    """
    Droplet formation mechanics and nucleation.
    
    In AnimaSpace WRM stage:
      1. Acoustic streaming pushes cells toward water surface
      2. Ultrasonic transducers atomize surface
      3. Individual cells/small groups incorporated into forming droplets
      4. Surface tension "seals" droplet
      5. Droplet separates and moves to transport phase
    
    Critical parameters:
      - Droplet size: Determines encapsulation (single cell vs. multiple)
      - Formation frequency: Throughput
      - Cell incorporation efficiency: What fraction of cells end up in droplets
    """
    
    def __init__(self, medium: MediumProperties, cell: CellProperties):
        """Initialize droplet formation system."""
        self.medium = medium
        self.cell = cell
        self.transducer_frequency_hz = 1e6  # Default: 1 MHz
        
        logger.info(f"DropletFormation initialized")
        logger.info(f"  Medium: {medium.name}")
        logger.info(f"  Cell type: {cell.cell_type}")
    
    def ideal_droplet_radius_single_cell(self) -> float:
        """
        Calculate ideal droplet radius to reliably encapsulate single cell.
        
        Strategy: Droplet diameter should be 2-3× cell diameter to provide:
          - Space for cell to fit comfortably
          - Minimal medium space (avoids multiple cells)
          - Sufficient internal volume for oxygenation over seconds
        
        Recommendation: r_droplet ≈ 1.5 × r_cell
        """
        r_ideal = 1.5 * self.cell.radius_m
        return r_ideal
    
    def ideal_droplet_volume_single_cell(self) -> float:
        """Volume of ideal single-cell droplet."""
        r = self.ideal_droplet_radius_single_cell()
        V = (4.0/3.0) * np.pi * r**3
        return V
    
    def minimum_droplet_radius_separation(self) -> float:
        """
        Minimum droplet radius before Rayleigh instability causes breakup.
        
        Plateau-Rayleigh instability: A liquid column (or very thin droplet)
        is unstable if its aspect ratio exceeds a critical value.
        
        For a sphere: No Plateau-Rayleigh limit (stable at all sizes).
        
        For practical purposes in atomization, the minimum practical size
        is limited by the atomizing transducer frequency and medium properties.
        
        Rough estimate: r_min ≈ λ/(2π) where λ = wavelength
        """
        wavelength = self.medium.sound_speed_m_s / self.transducer_frequency_hz
        r_min = wavelength / (2.0 * np.pi)
        
        return r_min
    
    def laplace_pressure_single_cell_droplet(self) -> float:
        """Laplace pressure for ideal single-cell droplet."""
        r = self.ideal_droplet_radius_single_cell()
        sigma = SurfaceTension.water_air_surface_tension(self.medium.temperature_c)
        
        delta_p = LaplacePressure.pressure_jump_sphere(r, sigma)
        return delta_p
    
    def surface_area_single_cell_droplet(self) -> float:
        """Surface area of ideal single-cell droplet."""
        r = self.ideal_droplet_radius_single_cell()
        A = 4.0 * np.pi * r**2
        return A
    
    def surface_energy_single_cell_droplet(self) -> float:
        """
        Surface energy (Helmholtz free energy) of the droplet.
        
        E_surface = σ · A
        
        Where:
          σ = surface tension (N/m)
          A = surface area (m²)
          E = energy (J)
        """
        sigma = SurfaceTension.water_air_surface_tension(self.medium.temperature_c)
        A = self.surface_area_single_cell_droplet()
        
        E = sigma * A
        return E
    
    def atomization_capillary_number(self, acoustic_pressure_pa: float,
                                    droplet_radius_m: float) -> float:
        """
        Capillary number: Balance between viscous/acoustic forces and surface tension.
        
        Ca = (acoustic force) / (surface tension force)
           = (ρ·v²·r) / σ
        
        Or in terms of pressure:
        Ca = (P·r) / σ
        
        Where:
          P = acoustic pressure (Pa)
          r = characteristic radius (m)
          σ = surface tension (N/m)
        
        Physical meaning:
          Ca << 1: Surface tension dominates (droplets maintain spherical shape)
          Ca >> 1: Viscous/acoustic forces dominate (droplet deformation/breakup)
        
        For controlled atomization: Ca ≈ 0.1 - 1.0
        """
        sigma = SurfaceTension.water_air_surface_tension(self.medium.temperature_c)
        
        Ca = (acoustic_pressure_pa * droplet_radius_m) / sigma
        
        return Ca
    
    def acoustic_power_for_atomization(self, target_droplet_radius_m: float) -> float:
        """
        Estimate acoustic power needed to maintain continuous droplet generation.
        
        Power is dissipated in:
          1. Overcoming surface tension (energy to create new surface)
          2. Viscous drag (movement and atomization)
          3. Acoustic streaming (bulk fluid motion)
        
        Rough estimate: P ≈ (generation_rate) × (energy_per_droplet)
        
        For single droplet formation:
        P ≈ σ · A · f
        
        Where:
          σ = surface tension
          A = new surface area created
          f = generation frequency
        """
        # Calculate droplet surface area
        A = 4.0 * np.pi * target_droplet_radius_m**2
        
        # Surface tension
        sigma = SurfaceTension.water_air_surface_tension(self.medium.temperature_c)
        
        # Generation frequency (assume 1 kHz as example)
        f_gen = 1000.0  # Hz
        
        # Power estimate
        P_surface = sigma * A * f_gen
        
        logger.info(f"Atomization power estimate: {P_surface:.3e} W for {f_gen/1000:.1f} kHz generation")
        
        return P_surface
    
    def cell_incorporation_probability(self,
                                      total_cells_near_surface: int,
                                      droplet_volume_m3: float,
                                      bulk_volume_m3: float) -> float:
        """
        Probability that a given cell ends up in a forming droplet.
        
        Simple model:
          - Cells are uniformly distributed near surface
          - Droplet captures a volume v_droplet from volume v_bulk
          - Probability ∝ (v_droplet / v_bulk)
        
        This is a lower-bound estimate; acoustic streaming can enhance pickup.
        
        Returns: Probability (0 to 1)
        """
        if bulk_volume_m3 == 0:
            return 0.0
        
        p_capture = droplet_volume_m3 / bulk_volume_m3
        
        return min(p_capture, 1.0)
    
    def __str__(self) -> str:
        """Summary of droplet formation configuration."""
        r_ideal = self.ideal_droplet_radius_single_cell()
        V_ideal = self.ideal_droplet_volume_single_cell()
        delta_p = self.laplace_pressure_single_cell_droplet()
        r_min = self.minimum_droplet_radius_separation()
        
        return f"""\
DropletFormation Summary
========================
Medium: {self.medium.name}
Cell type: {self.cell.cell_type}

Ideal single-cell droplet:
  Radius: {r_ideal*1e6:.1f} μm
  Volume: {V_ideal*1e9:.2f} pL
  Laplace pressure: {delta_p:.1f} Pa ({delta_p/1000:.3f} kPa)
  Surface area: {self.surface_area_single_cell_droplet()*1e9:.2f} μm²
  Surface energy: {self.surface_energy_single_cell_droplet()*1e12:.2e} pJ

Atomization limits:
  Minimum radius (Rayleigh): {r_min*1e6:.1f} μm
  Transducer frequency: {self.transducer_frequency_hz/1e6:.1f} MHz
"""


class DropletNucleation:
    """
    Nucleation of droplets from bulk liquid or captured bubbles.
    
    Mechanisms:
      1. Acoustic atomization: Cavitation at liquid surface
      2. Bubble pinchoff: Captured air bubble separates
      3. Jetting: Liquid jet breaks into droplets
    """
    
    @staticmethod
    def nucleation_energy_barrier(droplet_radius_m: float,
                                 surface_tension_n_m: float) -> float:
        """
        Energy barrier to forming a droplet from bulk liquid.
        
        The system must overcome the surface energy cost of creating
        the new interface.
        
        E_formation = σ · A = 4πσr²
        
        This energy comes from acoustic work or thermal activation.
        """
        A = 4.0 * np.pi * droplet_radius_m**2
        E = surface_tension_n_m * A
        
        return E
    
    @staticmethod
    def acoustic_work_to_form_droplet(acoustic_pressure_pa: float,
                                     droplet_radius_m: float,
                                     medium: MediumProperties) -> float:
        """
        Acoustic work done on a droplet during formation.
        
        W_acoustic ≈ P · ΔV
        
        Where:
          P = acoustic pressure amplitude (Pa)
          ΔV = volume change during formation
        
        For a forming droplet:
        W ≈ P_acoustic · (4/3)πr³
        """
        V = (4.0/3.0) * np.pi * droplet_radius_m**3
        W = acoustic_pressure_pa * V
        
        return W
    
    @staticmethod
    def critical_pressure_cavitation(surface_tension_n_m: float,
                                    nucleus_radius_m: float) -> float:
        """
        Critical (negative) pressure to collapse a bubble nucleus.
        
        A bubble of radius r will collapse if the pressure difference
        exceeds the Laplace pressure.
        
        P_critical = -2σ/r
        
        More negative (stronger suction) → faster collapse
        
        Relevance: Acoustic atomization relies on cavitation (collapse of bubbles)
        to create high-speed liquid jets that break into droplets.
        """
        P_crit = -2.0 * surface_tension_n_m / nucleus_radius_m
        
        return P_crit
