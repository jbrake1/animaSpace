"""
Acoustic Transducer Modeling and Field Calculations
=====================================================

Covers PMUT arrays, acoustic radiation pressure, acoustic streaming,
and toroidal formation physics.

Core equations:
  - Acoustic intensity: I = (1/2) * ρ * c * v² = P²/(2ρc)
  - Radiation pressure: P_rad = I/c = P²/(2ρc²)
  - Acoustic streaming velocity: v_stream ∝ (P²/c) / η
  - Gor'kov potential: Controls particle positioning in field

References:
  - Bruus, H. (2012): Acoustofluidics fundamentals
  - King, L.V. (1934): Acoustic radiation forces
  - Nyborg, W.L. (1958): Acoustic radiation pressure and streaming
  - Andrade, E.N.C. (1933): Acoustic streaming and vortices
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional, List
import logging

from .core_physics import PhysicsConstants, MediumProperties, CellProperties

logger = logging.getLogger(__name__)


@dataclass
class AcousticTransducer:
    """
    A single piezoelectric ultrasonic transducer (PMUT-like element).
    
    Represents one element in a phased array. Can be positioned and phased
    to create interference patterns and field steering.
    """
    
    # Electrical properties
    frequency_hz: float = 1e6  # Operating frequency (Hz), typically 0.5-5 MHz for PMUTs
    power_w: float = 1.0       # Electrical power input (W)
    efficiency: float = 0.6    # Transduction efficiency (electrical → acoustic)
    
    # Geometry
    diameter_m: float = 1e-3   # Element diameter (mm scale, typical PMUT)
    area_m2: float = None      # Radiating area (calculated)
    
    # Spatial positioning in array
    position_m: Tuple[float, float, float] = (0.0, 0.0, 0.0)  # x, y, z (meters)
    phase_deg: float = 0.0     # Phase offset (degrees, for beam steering)
    
    # Calculated acoustic properties
    acoustic_power_w: float = None  # Acoustic power (efficiency-corrected)
    acoustic_intensity_w_m2: float = None
    peak_pressure_pa: float = None
    
    def __post_init__(self):
        """Calculate derived acoustic properties."""
        self.area_m2 = np.pi * (self.diameter_m / 2.0)**2
        self.acoustic_power_w = self.efficiency * self.power_w
        self.acoustic_intensity_w_m2 = self.acoustic_power_w / self.area_m2
        
        logger.info(f"AcousticTransducer initialized:")
        logger.info(f"  Frequency: {self.frequency_hz/1e6:.1f} MHz")
        logger.info(f"  Power: {self.power_w:.2f} W → {self.acoustic_power_w:.2f} W acoustic")
        logger.info(f"  Element diameter: {self.diameter_m*1e3:.2f} mm")
        logger.info(f"  Radiating area: {self.area_m2:.3e} m²")
        logger.info(f"  Acoustic intensity: {self.acoustic_intensity_w_m2:.2e} W/m²")
    
    def peak_pressure(self, medium: MediumProperties) -> float:
        """
        Calculate peak acoustic pressure from intensity.
        
        Relationship: I = P²/(2·ρ·c)
        Solving for P: P = √(2·I·ρ·c)
        
        Where:
          I = acoustic intensity (W/m²)
          ρ = medium density (kg/m³)
          c = sound speed (m/s)
          P = peak pressure (Pa)
        
        Returns pressure in Pascals.
        """
        Z = medium.acoustic_impedance()  # ρ·c
        self.peak_pressure_pa = np.sqrt(2.0 * self.acoustic_intensity_w_m2 * Z)
        return self.peak_pressure_pa
    
    def wavelength(self, medium: MediumProperties) -> float:
        """
        Wavelength: λ = c / f
        
        Where:
          c = sound speed (m/s)
          f = frequency (Hz)
        
        Determines: interference patterns, array spacing, focal spot size
        """
        return medium.sound_speed_m_s / self.frequency_hz
    
    def wavelength_in_medium(self, medium: MediumProperties) -> float:
        """Alias for wavelength (for clarity)."""
        return self.wavelength(medium)
    
    def pressure_at_distance(self, distance_m: float, medium: MediumProperties) -> float:
        """
        Calculate pressure magnitude at a distance in the far field.
        
        Simple model: Spherical wavefront (geometric spreading)
        P(r) = P₀ · (r₀ / r)
        
        Where:
          P₀ = pressure at reference distance r₀
          r = distance of interest
          r₀ = reference distance (element radius)
        
        More accurate models would include:
          - Bessel function corrections (near field)
          - Attenuation coefficient (frequency-dependent)
          - Boundary effects
        """
        P0 = self.peak_pressure_pa
        r0 = self.diameter_m / 2.0
        
        if distance_m < r0:
            logger.warning(f"Distance {distance_m} < element radius {r0}, near-field regime")
        
        # Spherical spreading (far field)
        P = P0 * (r0 / distance_m)
        
        return P
    
    def set_phase(self, phase_deg: float):
        """Set transducer phase for phased-array beam steering."""
        self.phase_deg = phase_deg % 360.0


@dataclass
class PMUTArray:
    """
    Array of PMUT (Piezoelectric Micromachined Ultrasonic Transducer) elements
    operating coherently to create acoustic fields, radiation pressure, and streaming.
    
    Phased array control allows:
      - Beam steering (direction tuning)
      - Focal spot creation (constructive interference)
      - Toroidal vortex formation (specific phase patterns)
    """
    
    elements: List[AcousticTransducer]  # Array of transducer elements
    
    # Array-level properties
    name: str = "PMUT_Array_Default"
    total_elements: int = None  # Calculated
    element_spacing_m: float = None  # Spacing between elements
    
    def __post_init__(self):
        """Initialize array metadata."""
        self.total_elements = len(self.elements)
        logger.info(f"PMUTArray '{self.name}' initialized with {self.total_elements} elements")
    
    def set_phased_pattern(self, pattern_type: str, focal_distance_m: Optional[float] = None):
        """
        Apply a phased pattern to all elements.
        
        Patterns:
          - 'plane_wave': All elements in phase (plane wavefront)
          - 'focused': Concave phase pattern (focal point at focal_distance_m)
          - 'vortex': Spiral phase pattern for toroidal vortex
          - 'steering_xy': Steer beam toward +x, +y direction
        """
        if pattern_type == 'plane_wave':
            for elem in self.elements:
                elem.phase_deg = 0.0
            logger.info("Applied plane-wave pattern (all elements in phase)")
        
        elif pattern_type == 'focused' and focal_distance_m is not None:
            # Phase each element such that waves converge at focal_distance_m
            # Simpler model: elements farther from focal axis delay their phase
            for elem in self.elements:
                dist_to_focus = np.sqrt(
                    (elem.position_m[0])**2 + 
                    (elem.position_m[1])**2 + 
                    (focal_distance_m - elem.position_m[2])**2
                )
                # Phase = (2π/λ) * (distance_to_focus - focal_distance)
                # For simplicity, use linear model
                phase_rad = (2.0 * np.pi / focal_distance_m) * (dist_to_focus - focal_distance_m)
                elem.phase_deg = np.degrees(phase_rad)
            logger.info(f"Applied focused pattern (focal distance: {focal_distance_m} m)")
        
        elif pattern_type == 'vortex':
            # Spiral phase pattern: φ(θ) = m·θ (topological charge m)
            for elem in self.elements:
                # Convert x, y position to polar angle
                theta = np.arctan2(elem.position_m[1], elem.position_m[0])
                m = 1  # Topological charge (create one vortex core)
                elem.phase_deg = np.degrees(m * theta)
            logger.info(f"Applied vortex pattern (topological charge: 1)")
        
        else:
            logger.warning(f"Unknown pattern type: {pattern_type}")
    
    def total_acoustic_power(self) -> float:
        """Sum acoustic power from all elements."""
        return sum(elem.acoustic_power_w for elem in self.elements)
    
    def average_peak_pressure(self, medium: MediumProperties) -> float:
        """Calculate average peak pressure across array."""
        pressures = [elem.peak_pressure(medium) for elem in self.elements]
        return np.mean(pressures)


class AcousticRadiationPressure:
    """
    Acoustic radiation pressure and forces on particles.
    
    Core principle: Acoustic waves carry momentum. When a wave is absorbed
    or scattered, it imparts a force on the target.
    
    Key equations:
      - Acoustic intensity: I = (1/2) * ρ * c * v² = P²/(2ρc)
      - Radiation pressure: P_rad = I/c = P²/(2ρc²)
      - Acoustic radiation force (Gor'kov): F_rad = -∇U, where U is potential
      - For small particles: F_rad ∝ V_particle * acoustic_contrast * (k·r)²
    
    References:
      - King, L.V. (1934): "On the Acoustic Radiation Pressure"
      - Bruus, H. (2012): "Acoustofluidics fundamentals"
    """
    
    @staticmethod
    def radiation_pressure_from_intensity(intensity_w_m2: float, 
                                         medium: MediumProperties) -> float:
        """
        Calculate acoustic radiation pressure from acoustic intensity.
        
        Equation: P_rad = I / c
        
        Where:
          I = acoustic intensity (W/m²)
          c = sound speed (m/s)
          P_rad = radiation pressure (Pa)
        
        Alternative form (using impedance):
          P_rad = I / c = P²/(2ρc²)
        """
        return intensity_w_m2 / medium.sound_speed_m_s
    
    @staticmethod
    def radiation_pressure_from_pressure(peak_pressure_pa: float,
                                        medium: MediumProperties) -> float:
        """
        Calculate radiation pressure from acoustic pressure amplitude.
        
        Equation: P_rad = P²/(2ρc²)
        
        This is the time-averaged pressure exerted by the acoustic field.
        """
        Z = medium.acoustic_impedance()
        return (peak_pressure_pa**2) / (2.0 * Z * medium.sound_speed_m_s)
    
    @staticmethod
    def acoustic_force_on_particle(particle: CellProperties,
                                  medium: MediumProperties,
                                  peak_pressure_pa: float,
                                  frequency_hz: float) -> float:
        """
        Acoustic radiation force on a small particle (cell).
        
        Gor'kov's formula for a sphere in a plane wave:
        F_rad = -4πε₀V·∇|p|² where ε₀ is acoustic compressibility
        
        For practical calculation, use the acoustic contrast factor:
        F_rad ≈ (2π·V·β_medium·γ / (1 + γ)) · (P_rms)² · ∇(P²/|p₀|²)
        
        Simplified for uniform field gradient:
        F_rad ≈ (4π/3) · (ω²·V·ρ_medium·γ) / (1 + γ) · a
        
        Where:
          V = particle volume (m³)
          γ = acoustic_contrast = (ρ_cell/ρ_medium) - 1
          ω = angular frequency = 2πf
          ρ = medium density
          a = field acceleration (∝ pressure gradient)
        
        Returns force in Newtons
        """
        # Update acoustic contrast
        particle.update_acoustic_contrast(medium.density_kg_m3)
        
        V = (4.0/3.0) * np.pi * (particle.radius_m**3)
        omega = 2.0 * np.pi * frequency_hz
        gamma = particle.acoustic_contrast
        
        # Radiation force amplitude (proportional to P²)
        # This is a simplified model; full Gor'kov calculation requires field gradients
        Z = medium.acoustic_impedance()
        I = (peak_pressure_pa**2) / (2.0 * Z)
        
        # Force ∝ volume × contrast × intensity
        F_rad = V * gamma * I / medium.sound_speed_m_s
        
        logger.debug(f"Acoustic radiation force: {F_rad:.3e} N")
        logger.debug(f"  Particle volume: {V:.3e} m³")
        logger.debug(f"  Acoustic contrast: {gamma:.4f}")
        logger.debug(f"  Intensity: {I:.2e} W/m²")
        
        return F_rad


class AcousticStreaming:
    """
    Acoustic streaming: Bulk fluid motion driven by acoustic waves.
    
    In the presence of acoustic fields (especially at high intensity),
    the time-averaged nonlinear interaction creates steady fluid motion.
    
    Mechanisms:
      1. Eckart streaming (boundary-driven): Near solid surfaces
      2. Schlichting streaming (vortex formation): Bulk fluid
    
    Key scales:
      - Streaming velocity ∝ (P²/c) / η (pressure-squared dependent)
      - Streaming length scale ∝ λ (wavelength)
      - In microgravity, streaming can create toroidal vortices
    
    References:
      - Andrade, E.N.C. (1933): "The viscous flow in acoustic fields"
      - Nyborg, W.L. (1958): "Acoustic streaming near a boundary"
      - Bruus, H. (2012): "Acoustofluidic streaming at MHz frequencies"
    """
    
    @staticmethod
    def streaming_velocity_estimate(peak_pressure_pa: float,
                                   medium: MediumProperties,
                                   frequency_hz: float) -> float:
        """
        Estimate acoustic streaming velocity (bulk fluid motion).
        
        Empirical relation (Nyborg, 1958):
        v_stream ≈ (P²/c) / (ρ·η·ω)
        
        Where:
          P = peak acoustic pressure (Pa)
          c = sound speed (m/s)
          ρ = medium density (kg/m³)
          η = dynamic viscosity (Pa·s)
          ω = angular frequency (rad/s)
        
        This is an order-of-magnitude estimate; actual streaming patterns
        depend strongly on boundary conditions and field geometry.
        
        Returns velocity in m/s
        """
        omega = 2.0 * np.pi * frequency_hz
        
        # Streaming velocity ~ (P²/c) / (ρ·η·ω)
        numerator = peak_pressure_pa**2 / medium.sound_speed_m_s
        denominator = medium.density_kg_m3 * medium.dynamic_viscosity_pa_s * omega
        
        v_stream = numerator / denominator
        
        return v_stream
    
    @staticmethod
    def toroidal_vortex_radius(frequency_hz: float,
                              medium: MediumProperties) -> float:
        """
        Estimate radius of toroidal vortex in microgravity.
        
        In zero gravity, acoustic fields can sustain stable toroidal vortex
        structures (documented in NASA DECLIC experiments).
        
        Vortex radius ∝ λ (wavelength)
        Empirical relation: r_toroid ≈ 0.5 to 2.0 × λ
        
        For AnimaSpace droplet manipulation:
          - Smaller frequency → larger toroid
          - Allows multi-mm diameter vortices for cell positioning
        """
        wavelength = medium.sound_speed_m_s / frequency_hz
        r_toroid = wavelength  # Central estimate
        
        return r_toroid
    
    @staticmethod
    def streaming_power_loss(peak_pressure_pa: float,
                            medium: MediumProperties,
                            frequency_hz: float,
                            volume_m3: float) -> float:
        """
        Estimate acoustic power dissipated via streaming.
        
        Energy input to create streaming: P_stream ≈ (P²·V·ω) / (ρ·c·η)
        
        This represents power "lost" from directed compression/expansion
        and converted into bulk flow.
        
        Returns power in Watts
        """
        omega = 2.0 * np.pi * frequency_hz
        Z = medium.acoustic_impedance()
        
        P_dissipated = (peak_pressure_pa**2 * volume_m3 * omega) / (2.0 * Z * medium.dynamic_viscosity_pa_s)
        
        return P_dissipated


def create_linear_array_1d(num_elements: int = 8,
                          spacing_m: float = 1e-3,
                          frequency_hz: float = 1e6,
                          power_per_element_w: float = 0.5) -> PMUTArray:
    """
    Factory function: Create a 1D linear PMUT array.
    
    Typical configuration for phased-array steering.
    """
    elements = []
    for i in range(num_elements):
        elem = AcousticTransducer(
            frequency_hz=frequency_hz,
            power_w=power_per_element_w,
            position_m=(i * spacing_m, 0.0, 0.0),
        )
        elements.append(elem)
    
    return PMUTArray(elements=elements, name="LinearArray_1D", element_spacing_m=spacing_m)


def create_circular_array_2d(num_elements: int = 16,
                            array_radius_m: float = 5e-3,
                            frequency_hz: float = 1e6,
                            power_per_element_w: float = 0.5) -> PMUTArray:
    """
    Factory function: Create a 2D circular PMUT array.
    
    Useful for creating focused beams and toroidal vortices.
    """
    elements = []
    for i in range(num_elements):
        angle = 2.0 * np.pi * i / num_elements
        x = array_radius_m * np.cos(angle)
        y = array_radius_m * np.sin(angle)
        
        elem = AcousticTransducer(
            frequency_hz=frequency_hz,
            power_w=power_per_element_w,
            position_m=(x, y, 0.0),
        )
        elements.append(elem)
    
    return PMUTArray(elements=elements, name="CircularArray_2D", element_spacing_m=2.0*array_radius_m)
