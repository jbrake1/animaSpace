"""
Entry point for running AnimaSpace examples.

Usage: python -m animaspace_simulator
"""

from .example_usage import main

if __name__ == "__main__":
    main()
