"""
Transit Simulation: Gas and Liquid Phase Movement
==================================================

Models droplet trajectory and motion through:
  1. Gas phase: WRM → Bio-reactor (millisecond scale, high speed)
  2. Liquid phase: Bio-reactor → Deposition unit (second scale, controlled)

Equation of motion (in both media):
  m·dv/dt = F_acoustic + F_gravity + F_drag
  
In microgravity (F_gravity ≈ 0):
  m·dv/dt = F_acoustic + F_drag

For Stokes flow (low Re):
  At quasi-steady state: F_acoustic = F_drag
  Therefore: v_steady = F_acoustic / (6πηr)

Key insight:
  Gas has ~1000× lower viscosity than water → faster transit
  But also lower density → lower acoustic radiation force effect
  
Net result: Gas-phase transit is 10-100× faster than liquid-phase
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, List, Optional
import logging

from .core_physics import PhysicsConstants, MediumProperties, CellProperties
from .acoustic import AcousticTransducer, PMUTArray, AcousticRadiationPressure, AcousticStreaming
from .fluids import StokesFluid, DragCalculator
from .droplet import DropletFormation

logger = logging.getLogger(__name__)


@dataclass
class TransitTrajectory:
    """
    Trajectory data for a droplet during transit.
    
    Stores position, velocity, forces at each time step.
    """
    
    time_steps: List[float]  # Time (s)
    positions: List[Tuple[float, float, float]]  # Position (m) [x, y, z]
    velocities: List[float]  # Speed (m/s)
    forces_acoustic: List[float]  # Acoustic radiation force (N)
    forces_drag: List[float]  # Drag force (N)
    reynolds_numbers: List[float]  # Re at each step
    
    distance_total_m: float = None  # Total distance traveled
    time_total_s: float = None  # Total time
    
    def __post_init__(self):
        """Calculate summary statistics."""
        if len(self.positions) > 1:
            # Calculate total distance
            self.distance_total_m = 0.0
            for i in range(1, len(self.positions)):
                dx = (self.positions[i][0] - self.positions[i-1][0])**2
                dy = (self.positions[i][1] - self.positions[i-1][1])**2
                dz = (self.positions[i][2] - self.positions[i-1][2])**2
                self.distance_total_m += np.sqrt(dx + dy + dz)
            
            self.time_total_s = self.time_steps[-1] - self.time_steps[0] if len(self.time_steps) > 1 else 0.0


class GasPhaseTransit:
    """
    Droplet transit through gas phase (air).
    
    Advantages:
      - Low viscosity → high terminal velocity
      - Low drag → precise control
      - Fast transit (milliseconds) → minimal cell stress
    
    Challenges:
      - Osmotic gradient (water vapor loss)
      - Lower acoustic radiation force
      - Static electricity hazards
    
    For AnimaSpace: Gas transit is seconds-scale, osmotic effects are negligible.
    """
    
    def __init__(self, droplet: DropletFormation,
                 gas_medium: MediumProperties,
                 transducer: AcousticTransducer):
        """Initialize gas-phase transit model."""
        self.droplet = droplet
        self.medium = gas_medium
        self.transducer = transducer
        self.stokes_fluid = StokesFluid(gas_medium)
        self.drag_calculator = DragCalculator()
        
        logger.info("GasPhaseTransit initialized (air medium)")
        logger.info(f"  Medium viscosity: {gas_medium.dynamic_viscosity_pa_s:.3e} Pa·s")
    
    def velocity_terminal_gas_phase(self, droplet_radius_m: float) -> float:
        """
        Terminal velocity of droplet in air (no gravity in microgravity).
        
        Driven by acoustic radiation force only.
        V_terminal = F_acoustic / (6πηr)
        """
        P_peak = self.transducer.peak_pressure(self.medium)
        
        # Acoustic radiation force on droplet
        particle = CellProperties(diameter_um=droplet_radius_m*2e6, density_kg_m3=1000.0)
        F_rad = AcousticRadiationPressure.acoustic_force_on_particle(
            particle, self.medium, P_peak, self.transducer.frequency_hz
        )
        
        # Terminal velocity
        v_term = self.stokes_fluid.acoustic_force_terminal_velocity(particle, F_rad)
        
        return v_term
    
    def time_to_terminal_velocity_gas(self, droplet_radius_m: float) -> float:
        """
        Time constant for droplet to reach terminal velocity in air.
        
        τ = (2r²ρ_droplet) / (9η_air)
        
        Typically very fast (microseconds to milliseconds) due to low mass
        and low viscosity.
        """
        rho_droplet = 1000.0  # Water
        tau = (2.0 * droplet_radius_m**2 * rho_droplet) / (9.0 * self.medium.dynamic_viscosity_pa_s)
        
        return tau
    
    def simulate_trajectory(self, start_position_m: Tuple[float, float, float],
                           end_position_m: Tuple[float, float, float],
                           droplet_radius_m: float,
                           dt_s: float = 0.0001) -> TransitTrajectory:
        """
        Simulate droplet trajectory from start to end position in gas phase.
        
        Equation of motion:
        m·dv/dt = F_acoustic - 6πηrv
        
        At low Reynolds, reaches quasi-steady state quickly.
        """
        # Calculate initial conditions
        v_term = self.velocity_terminal_gas_phase(droplet_radius_m)
        tau = self.time_to_terminal_velocity_gas(droplet_radius_m)
        
        # Distance to travel
        dx = end_position_m[0] - start_position_m[0]
        dy = end_position_m[1] - start_position_m[1]
        dz = end_position_m[2] - start_position_m[2]
        distance = np.sqrt(dx**2 + dy**2 + dz**2)
        
        # Travel time (approximation)
        travel_time_est = distance / v_term if v_term > 0 else np.inf
        
        # Simulation parameters
        time_steps = []
        positions = []
        velocities = []
        forces_acoustic = []
        forces_drag = []
        reynolds_numbers = []
        
        t = 0.0
        position = np.array(start_position_m, dtype=float)
        velocity = 0.0
        
        # Direction unit vector
        if distance > 0:
            direction = np.array([dx, dy, dz]) / distance
        else:
            direction = np.array([1.0, 0.0, 0.0])
        
        # Run simulation
        P_peak = self.transducer.peak_pressure(self.medium)
        particle = CellProperties(diameter_um=droplet_radius_m*2e6, density_kg_m3=1000.0)
        F_acoustic = AcousticRadiationPressure.acoustic_force_on_particle(
            particle, self.medium, P_peak, self.transducer.frequency_hz
        )
        
        mass = (4.0/3.0) * np.pi * droplet_radius_m**3 * 1000.0
        
        max_iterations = int(travel_time_est * 10.0 / dt_s)  # 10× travel time buffer
        max_iterations = min(max_iterations, 100000)  # Cap iterations
        
        for iteration in range(max_iterations):
            # Drag force
            F_drag = 6.0 * np.pi * self.medium.dynamic_viscosity_pa_s * droplet_radius_m * velocity
            
            # Acceleration
            if mass > 0:
                accel = (F_acoustic - F_drag) / mass
            else:
                accel = 0.0
            
            # Update velocity
            velocity = max(0.0, velocity + accel * dt_s)
            
            # Update position
            position = position + velocity * direction * dt_s
            
            # Check if reached destination
            dist_remaining = np.linalg.norm(end_position_m - position)
            if dist_remaining < 1e-6:
                logger.info(f"Reached destination at t={t:.4e} s")
                break
            
            # Record
            time_steps.append(t)
            positions.append(tuple(position))
            velocities.append(velocity)
            forces_acoustic.append(F_acoustic)
            forces_drag.append(F_drag)
            
            # Reynolds number
            Re = self.medium.reynolds_number(velocity, 2.0*droplet_radius_m)
            reynolds_numbers.append(Re)
            
            t += dt_s
        
        logger.info(f"Gas-phase transit complete: {len(time_steps)} steps, total time {t:.3e} s")
        
        trajectory = TransitTrajectory(
            time_steps=time_steps,
            positions=positions,
            velocities=velocities,
            forces_acoustic=forces_acoustic,
            forces_drag=forces_drag,
            reynolds_numbers=reynolds_numbers,
        )
        
        return trajectory


class LiquidPhaseTransit:
    """
    Droplet transit through liquid phase (culture medium or water).
    
    Characteristics:
      - High viscosity → low terminal velocity
      - Strong drag coupling → slow response to steering
      - Long transit time (seconds) → allows fine control
      - Osmotic safe (no water loss)
      - Can use phased-array beam steering for precision
    """
    
    def __init__(self, droplet: DropletFormation,
                 liquid_medium: MediumProperties,
                 transducer_array: PMUTArray):
        """Initialize liquid-phase transit model."""
        self.droplet = droplet
        self.medium = liquid_medium
        self.transducer_array = transducer_array
        self.stokes_fluid = StokesFluid(liquid_medium)
        self.drag_calculator = DragCalculator()
        
        logger.info("LiquidPhaseTransit initialized (water/culture medium)")
        logger.info(f"  Medium viscosity: {liquid_medium.dynamic_viscosity_pa_s:.3e} Pa·s")
    
    def velocity_terminal_liquid_phase(self, droplet_radius_m: float) -> float:
        """
        Terminal velocity of droplet in liquid phase.
        
        Typically much slower than gas phase due to higher viscosity.
        """
        P_peak = self.transducer_array.average_peak_pressure(self.medium)
        
        # Acoustic radiation force
        particle = CellProperties(diameter_um=droplet_radius_m*2e6, density_kg_m3=1000.0)
        F_rad = AcousticRadiationPressure.acoustic_force_on_particle(
            particle, self.medium, P_peak, self.transducer_array.elements[0].frequency_hz
        )
        
        # Terminal velocity
        v_term = self.stokes_fluid.acoustic_force_terminal_velocity(particle, F_rad)
        
        return v_term
    
    def time_to_terminal_velocity_liquid(self, droplet_radius_m: float) -> float:
        """
        Time to reach terminal velocity in liquid.
        
        τ = (2r²ρ_droplet) / (9η_liquid)
        
        Much longer than in air, but still typically sub-millisecond.
        """
        rho_droplet = 1000.0
        tau = (2.0 * droplet_radius_m**2 * rho_droplet) / (9.0 * self.medium.dynamic_viscosity_pa_s)
        
        return tau
    
    def simulate_trajectory(self, start_position_m: Tuple[float, float, float],
                           end_position_m: Tuple[float, float, float],
                           droplet_radius_m: float,
                           dt_s: float = 0.001) -> TransitTrajectory:
        """
        Simulate droplet trajectory in liquid phase with phased-array steering.
        
        Uses finer time resolution (dt = 1 ms) for better control tracking.
        """
        # Calculate initial conditions
        v_term = self.velocity_terminal_liquid_phase(droplet_radius_m)
        tau = self.time_to_terminal_velocity_liquid(droplet_radius_m)
        
        # Distance to travel
        dx = end_position_m[0] - start_position_m[0]
        dy = end_position_m[1] - start_position_m[1]
        dz = end_position_m[2] - start_position_m[2]
        distance = np.sqrt(dx**2 + dy**2 + dz**2)
        
        # Travel time estimate
        travel_time_est = distance / v_term if v_term > 0 else np.inf
        
        # Simulation
        time_steps = []
        positions = []
        velocities = []
        forces_acoustic = []
        forces_drag = []
        reynolds_numbers = []
        
        t = 0.0
        position = np.array(start_position_m, dtype=float)
        velocity = 0.0
        
        # Direction
        if distance > 0:
            direction = np.array([dx, dy, dz]) / distance
        else:
            direction = np.array([1.0, 0.0, 0.0])
        
        # Acoustic force
        P_peak = self.transducer_array.average_peak_pressure(self.medium)
        particle = CellProperties(diameter_um=droplet_radius_m*2e6, density_kg_m3=1000.0)
        F_acoustic = AcousticRadiationPressure.acoustic_force_on_particle(
            particle, self.medium, P_peak, self.transducer_array.elements[0].frequency_hz
        )
        
        mass = (4.0/3.0) * np.pi * droplet_radius_m**3 * 1000.0
        
        # Run simulation
        max_iterations = int(travel_time_est * 10.0 / dt_s)
        max_iterations = min(max_iterations, 100000)
        
        for iteration in range(max_iterations):
            # Drag
            F_drag = 6.0 * np.pi * self.medium.dynamic_viscosity_pa_s * droplet_radius_m * velocity
            
            # Acceleration
            if mass > 0:
                accel = (F_acoustic - F_drag) / mass
            else:
                accel = 0.0
            
            # Update
            velocity = max(0.0, velocity + accel * dt_s)
            position = position + velocity * direction * dt_s
            
            # Distance check
            dist_remaining = np.linalg.norm(np.array(end_position_m) - position)
            if dist_remaining < 1e-6:
                logger.info(f"Reached destination at t={t:.4e} s")
                break
            
            # Record
            time_steps.append(t)
            positions.append(tuple(position))
            velocities.append(velocity)
            forces_acoustic.append(F_acoustic)
            forces_drag.append(F_drag)
            
            Re = self.medium.reynolds_number(velocity, 2.0*droplet_radius_m)
            reynolds_numbers.append(Re)
            
            t += dt_s
        
        logger.info(f"Liquid-phase transit complete: {len(time_steps)} steps, total time {t:.3e} s")
        
        trajectory = TransitTrajectory(
            time_steps=time_steps,
            positions=positions,
            velocities=velocities,
            forces_acoustic=forces_acoustic,
            forces_drag=forces_drag,
            reynolds_numbers=reynolds_numbers,
        )
        
        return trajectory


class TransitSimulator:
    """
    High-level simulator coordinating gas and liquid phase transits.
    
    Pipeline:
      WRM → [gas phase] → Bio-reactor → [liquid phase] → Deposition unit
    """
    
    def __init__(self, transducer_gas: AcousticTransducer,
                 transducer_array_liquid: PMUTArray,
                 gas_medium: MediumProperties,
                 liquid_medium: MediumProperties):
        """Initialize full transit simulator."""
        self.transducer_gas = transducer_gas
        self.transducer_array_liquid = transducer_array_liquid
        self.gas_medium = gas_medium
        self.liquid_medium = liquid_medium
        
        logger.info("TransitSimulator initialized")
    
    def simulate_full_pipeline(self,
                              wrm_position_m: Tuple[float, float, float],
                              bioreactor_position_m: Tuple[float, float, float],
                              deposition_position_m: Tuple[float, float, float],
                              droplet_radius_m: float) -> dict:
        """
        Simulate complete droplet journey through all phases.
        
        Returns dictionary with:
          - gas_phase_trajectory
          - liquid_phase_trajectory
          - total_time
          - speed_comparison
        """
        logger.info("=" * 60)
        logger.info("FULL PIPELINE SIMULATION")
        logger.info("=" * 60)
        
        # Create droplet formation model (dummy, for references)
        dummy_cell = CellProperties()
        dummy_medium = MediumProperties(name='water')
        droplet = DropletFormation(dummy_medium, dummy_cell)
        
        # Gas phase: WRM → Bio-reactor
        logger.info("\n[1] GAS PHASE TRANSIT: WRM → Bio-reactor")
        gas_transit = GasPhaseTransit(droplet, self.gas_medium, self.transducer_gas)
        trajectory_gas = gas_transit.simulate_trajectory(
            wrm_position_m, bioreactor_position_m, droplet_radius_m
        )
        
        # Liquid phase: Bio-reactor → Deposition
        logger.info("\n[2] LIQUID PHASE TRANSIT: Bio-reactor → Deposition")
        liquid_transit = LiquidPhaseTransit(droplet, self.liquid_medium, self.transducer_array_liquid)
        trajectory_liquid = liquid_transit.simulate_trajectory(
            bioreactor_position_m, deposition_position_m, droplet_radius_m
        )
        
        # Summary
        logger.info("\n" + "=" * 60)
        logger.info("TRANSIT SUMMARY")
        logger.info("=" * 60)
        
        total_time = trajectory_gas.time_total_s + trajectory_liquid.time_total_s
        
        logger.info(f"Droplet radius: {droplet_radius_m*1e6:.1f} μm")
        logger.info(f"\nGas phase:")
        logger.info(f"  Distance: {trajectory_gas.distance_total_m:.3f} m")
        logger.info(f"  Time: {trajectory_gas.time_total_s:.3e} s")
        logger.info(f"  Avg speed: {trajectory_gas.distance_total_m/trajectory_gas.time_total_s:.3f} m/s")
        
        logger.info(f"\nLiquid phase:")
        logger.info(f"  Distance: {trajectory_liquid.distance_total_m:.3f} m")
        logger.info(f"  Time: {trajectory_liquid.time_total_s:.3e} s")
        logger.info(f"  Avg speed: {trajectory_liquid.distance_total_m/trajectory_liquid.time_total_s:.3f} m/s")
        
        logger.info(f"\nTotal time: {total_time:.3e} s")
        logger.info(f"Speed ratio (gas/liquid): {(trajectory_gas.distance_total_m/trajectory_gas.time_total_s) / (trajectory_liquid.distance_total_m/trajectory_liquid.time_total_s):.1f}×")
        
        return {
            'trajectory_gas': trajectory_gas,
            'trajectory_liquid': trajectory_liquid,
            'total_time_s': total_time,
            'gas_avg_speed_m_s': trajectory_gas.distance_total_m / trajectory_gas.time_total_s if trajectory_gas.time_total_s > 0 else 0,
            'liquid_avg_speed_m_s': trajectory_liquid.distance_total_m / trajectory_liquid.time_total_s if trajectory_liquid.time_total_s > 0 else 0,
        }
