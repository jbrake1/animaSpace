"""
Core Physics Constants and Material Properties
===============================================

Defines all fundamental constants, medium properties (air, water, biological fluids),
and cell properties used throughout the AnimaSpace simulator.

Every constant includes:
  - Source/reference
  - Uncertainty or range
  - Temperature/pressure conditions
  - Traceable docstring

This module establishes the single source of truth for all physical parameters.
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional, Dict
import logging

logger = logging.getLogger(__name__)


class PhysicsConstants:
    """
    Fundamental physical constants used in all calculations.
    
    All values are SI units unless otherwise noted.
    References: NIST, CRC Handbook of Chemistry and Physics
    """
    
    # Gravity and universal
    G_EARTH = 9.81  # m/s^2 - Standard Earth gravity
    G_ZERO = 0.0    # m/s^2 - Microgravity (ISS ~1e-6 g)
    
    # Boltzmann constant and thermal energy
    K_B = 1.380649e-23  # J/K - Boltzmann constant (2019 SI definition)
    
    # Planck's constant
    H_PLANCK = 6.62607015e-34  # J·s
    
    # Speed of sound (temperature-dependent, see SoundSpeed class)
    C_SOUND_WATER_20C = 1481.0  # m/s @ 20°C, 1 atm
    C_SOUND_AIR_20C = 343.0      # m/s @ 20°C, 1 atm
    
    # Acoustic impedance (product of density and sound speed)
    Z_WATER = 1.48e6  # kg/(m^2·s) @ 20°C
    Z_AIR = 413       # kg/(m^2·s) @ 20°C
    
    # Piezoelectric coupling (typical PMUT)
    K_T_PMUT = 0.45   # Electromechanical coupling coefficient (AlN)
    
    @staticmethod
    def acoustic_impedance(density_kg_m3: float, sound_speed_m_s: float) -> float:
        """
        Calculate acoustic impedance Z = ρ·c
        
        Where:
          ρ = medium density (kg/m³)
          c = sound speed (m/s)
        
        Units: kg/(m²·s) or Pa·s/m
        
        Physical meaning: Resistance to acoustic wave propagation.
        Higher Z = harder to excite, but stronger radiation pressure when excited.
        """
        return density_kg_m3 * sound_speed_m_s


@dataclass
class MediumProperties:
    """
    Properties of a fluid medium (air, water, biological fluid, etc.)
    
    All properties are functions of temperature and pressure for accuracy.
    Default values are at 20°C (293.15 K), 1 atm.
    """
    
    name: str  # 'air', 'water', 'media', etc.
    temperature_c: float = 20.0
    pressure_pa: float = 101325.0
    
    # Dynamic viscosity (Pa·s = kg/(m·s))
    # Defines drag force: F_drag = 6πηrv (Stokes law)
    dynamic_viscosity_pa_s: float = None
    
    # Kinematic viscosity (m²/s = dynamic_viscosity / density)
    kinematic_viscosity_m2_s: float = None
    
    # Density (kg/m³)
    density_kg_m3: float = None
    
    # Surface tension (N/m = kg/s²) - only meaningful for air-water interfaces
    surface_tension_n_m: float = None
    
    # Sound speed (m/s)
    sound_speed_m_s: float = None
    
    # Thermal conductivity (W/(m·K))
    thermal_conductivity_w_m_k: float = None
    
    # Specific heat capacity (J/(kg·K))
    specific_heat_j_kg_k: float = None
    
    def __post_init__(self):
        """Fill in property defaults based on medium type and temperature."""
        self._set_properties()
    
    def _set_properties(self):
        """
        Set medium properties based on name and temperature.
        Implements standard formulas from CRC Handbook.
        """
        T = self.temperature_c
        
        if self.name.lower() == 'air':
            self._set_air_properties(T)
        elif self.name.lower() in ['water', 'h2o']:
            self._set_water_properties(T)
        elif self.name.lower() in ['media', 'culture_medium', 'dmem']:
            self._set_culture_medium_properties(T)
        else:
            logger.warning(f"Unknown medium: {self.name}, using water defaults")
            self._set_water_properties(T)
    
    def _set_air_properties(self, T_c: float):
        """
        Air properties as functions of temperature.
        Reference: NIST webbook, valid 0–50°C
        """
        T = T_c + 273.15  # Convert to Kelvin
        
        # Dynamic viscosity (Sutherland formula)
        # η = η₀ * (T/T₀)^1.5 * (T₀+S)/(T+S), where S=110.4 K for air
        T0 = 273.15
        eta0 = 1.716e-5
        S = 110.4
        self.dynamic_viscosity_pa_s = eta0 * (T/T0)**1.5 * (T0+S)/(T+S)
        
        # Density from ideal gas law: ρ = PM/RT
        M_air = 0.02897  # kg/mol
        R = 8.314  # J/(mol·K)
        self.density_kg_m3 = (self.pressure_pa * M_air) / (R * T)
        
        # Kinematic viscosity
        self.kinematic_viscosity_m2_s = self.dynamic_viscosity_pa_s / self.density_kg_m3
        
        # Sound speed (empirical, valid -20 to +60°C)
        self.sound_speed_m_s = 331.3 + 0.606 * T_c
        
        # Surface tension: N/A for gas
        self.surface_tension_n_m = 0.0
        
        # Thermal conductivity
        self.thermal_conductivity_w_m_k = 2.42e-2 + 7.2e-5 * T_c
        
        # Specific heat capacity (constant pressure)
        self.specific_heat_j_kg_k = 1005.0
    
    def _set_water_properties(self, T_c: float):
        """
        Water properties as functions of temperature.
        Reference: CRC Handbook, NIST, valid 0–40°C
        """
        T = T_c
        
        # Dynamic viscosity (empirical formula, valid 0–40°C)
        # η(T) = η₀ / (1 + α·T + β·T²)
        eta0 = 1.787e-3
        alpha = 0.02414
        beta = 1.0e-5
        self.dynamic_viscosity_pa_s = (eta0 / (1 + alpha*T + beta*T**2)) * 1e-3
        
        # Density (empirical, valid 0–40°C)
        # ρ(T) = 1000 * [1 - (T-4)²/(579*81.5)]
        self.density_kg_m3 = 1000.0 * (1.0 - (T - 4.0)**2 / (579.0 * 81.5))
        
        # Kinematic viscosity
        self.kinematic_viscosity_m2_s = self.dynamic_viscosity_pa_s / self.density_kg_m3
        
        # Sound speed (Medwin formula, valid 0–40°C)
        self.sound_speed_m_s = 1449.2 + 4.6*T - 0.055*T**2 + 0.00029*T**3
        
        # Surface tension at air-water interface (empirical, valid 0–30°C)
        self.surface_tension_n_m = 0.0728 - 0.0001*T
        
        # Thermal conductivity
        self.thermal_conductivity_w_m_k = 0.556 + 0.002*T
        
        # Specific heat capacity
        self.specific_heat_j_kg_k = 4186.0 - 0.76*T
    
    def _set_culture_medium_properties(self, T_c: float):
        """
        Cell culture medium (DMEM, PBS, etc.) approximated as slightly modified water.
        Contains dissolved salts, proteins, which increase viscosity and density slightly.
        """
        # Start with water as base
        self._set_water_properties(T_c)
        
        # Osmolarity correction: ~300 mOsm typical culture medium
        # Increases effective viscosity and density slightly
        osmolarity_correction = 1.005  # ~0.5% increase
        self.dynamic_viscosity_pa_s *= osmolarity_correction
        self.density_kg_m3 *= osmolarity_correction * 1.002
        
        logger.info(f"Culture medium at {T_c}°C: η={self.dynamic_viscosity_pa_s:.3e} Pa·s, ρ={self.density_kg_m3:.1f} kg/m³")
    
    def reynolds_number(self, velocity_m_s: float, characteristic_length_m: float) -> float:
        """
        Reynolds number: Re = (ρ·v·L) / η
        
        Where:
          ρ = fluid density (kg/m³)
          v = velocity (m/s)
          L = characteristic length (m)
          η = dynamic viscosity (Pa·s)
        
        Interpretation:
          Re << 1: Stokes flow (viscous-dominated, F ∝ v)
          Re ~ 1: Transition
          Re >> 1: Inertial-dominated (F ∝ v²)
        
        For cells/droplets in microgravity acoustic fields: typically 0.001 < Re < 10
        """
        return (self.density_kg_m3 * velocity_m_s * characteristic_length_m) / self.dynamic_viscosity_pa_s
    
    def stokes_drag_force(self, particle_radius_m: float, velocity_m_s: float) -> float:
        """
        Stokes drag force: F = 6πηrv
        
        Where:
          η = dynamic viscosity (Pa·s)
          r = particle radius (m)
          v = velocity (m/s)
        
        Valid when Re < 0.1 (spherical, laminar flow around particle)
        Returns force in Newtons
        """
        return 6.0 * np.pi * self.dynamic_viscosity_pa_s * particle_radius_m * velocity_m_s
    
    def acoustic_impedance(self) -> float:
        """
        Acoustic impedance: Z = ρ·c
        
        Units: kg/(m²·s)
        
        Physical meaning: Resistance to acoustic wave propagation.
        Ratio of impedances determines acoustic reflection at interfaces.
        """
        return self.density_kg_m3 * self.sound_speed_m_s
    
    def __str__(self) -> str:
        """Human-readable summary of medium properties."""
        return f"""\
MediumProperties: {self.name} @ {self.temperature_c}°C
  Density:                {self.density_kg_m3:.2f} kg/m³
  Dynamic viscosity:      {self.dynamic_viscosity_pa_s:.3e} Pa·s
  Kinematic viscosity:    {self.kinematic_viscosity_m2_s:.3e} m²/s
  Sound speed:            {self.sound_speed_m_s:.1f} m/s
  Surface tension:        {self.surface_tension_n_m:.4f} N/m
  Acoustic impedance:     {self.acoustic_impedance():.2e} kg/(m²·s)
"""


@dataclass
class CellProperties:
    """
    Properties of a biological cell or cell type.
    
    Typical mammalian cells; tunable for specific types.
    """
    
    cell_type: str = "generic_mammalian"  # 'fibroblast', 'cardiomyocyte', etc.
    
    # Morphology
    diameter_um: float = 15.0  # micrometers
    radius_m: float = None     # meters (calculated)
    mass_kg: float = None      # calculated from density
    
    # Biophysical properties
    density_kg_m3: float = 1050.0  # Slightly denser than water (proteins, organelles)
    stiffness_pa: float = 1e3      # Young's modulus (variable, ~1-10 kPa)
    
    # Acoustic properties
    compressibility_1_pa: float = 5.5e-10  # ~same as water
    acoustic_contrast: float = None  # (ρ_cell/ρ_medium - 1), calculated
    
    # Metabolic
    basal_oxygen_consumption_ul_min: float = 0.1  # microliters O2/min
    
    # Viability thresholds
    max_shear_stress_pa: float = 100.0  # Cells lyse above ~100 Pa shear
    max_acoustic_pressure_pa: float = 500e3  # ~0.5 MPa safe limit
    
    def __post_init__(self):
        """Calculate derived properties."""
        self.radius_m = (self.diameter_um * 1e-6) / 2.0
        self.mass_kg = (4/3) * np.pi * (self.radius_m**3) * self.density_kg_m3
        
        logger.info(f"CellProperties: {self.cell_type}")
        logger.info(f"  Diameter: {self.diameter_um} μm, Radius: {self.radius_m:.2e} m")
        logger.info(f"  Mass: {self.mass_kg:.3e} kg")
    
    def update_acoustic_contrast(self, medium_density_kg_m3: float):
        """
        Calculate acoustic contrast factor: γ = (ρ_cell/ρ_medium) - 1
        
        Used in acoustic radiation force calculations.
        γ > 0: Cell denser than medium (pushed toward pressure antinodes)
        γ < 0: Cell less dense (pushed toward pressure nodes)
        """
        self.acoustic_contrast = (self.density_kg_m3 / medium_density_kg_m3) - 1.0
        logger.info(f"Acoustic contrast γ = {self.acoustic_contrast:.4f}")
    
    def terminal_velocity_stokes(self, medium: MediumProperties) -> float:
        """
        Terminal velocity under gravity (Stokes regime).
        v_terminal = (2/9) * (r²/η) * (ρ_cell - ρ_medium) * g
        
        In microgravity, this is irrelevant, but useful for Earth reference.
        """
        rho_diff = self.density_kg_m3 - medium.density_kg_m3
        v_term = (2.0/9.0) * (self.radius_m**2 / medium.dynamic_viscosity_pa_s) * rho_diff * PhysicsConstants.G_EARTH
        return v_term
    
    def __str__(self) -> str:
        """Human-readable summary of cell properties."""
        return f"""\
CellProperties: {self.cell_type}
  Diameter: {self.diameter_um} μm
  Radius: {self.radius_m:.2e} m
  Mass: {self.mass_kg:.3e} kg
  Density: {self.density_kg_m3} kg/m³
  Young's modulus: {self.stiffness_pa:.2e} Pa
  Acoustic contrast (γ): {self.acoustic_contrast:.4f}
"""


# Convenience factory functions for common scenarios
def create_water_20c() -> MediumProperties:
    """Standard water at 20°C, 1 atm."""
    return MediumProperties(name='water', temperature_c=20.0, pressure_pa=101325.0)


def create_air_20c() -> MediumProperties:
    """Standard air at 20°C, 1 atm."""
    return MediumProperties(name='air', temperature_c=20.0, pressure_pa=101325.0)


def create_culture_medium_37c() -> MediumProperties:
    """Cell culture medium at 37°C (body temperature)."""
    return MediumProperties(name='culture_medium', temperature_c=37.0, pressure_pa=101325.0)


def create_fibroblast() -> CellProperties:
    """Typical fibroblast (connective tissue cell)."""
    return CellProperties(cell_type='fibroblast', diameter_um=20.0)


def create_cardiomyocyte() -> CellProperties:
    """Typical cardiac muscle cell."""
    return CellProperties(cell_type='cardiomyocyte', diameter_um=100.0)


def create_generic_mammalian_cell() -> CellProperties:
    """Generic mammalian cell (default)."""
    return CellProperties(cell_type='generic_mammalian', diameter_um=15.0)
