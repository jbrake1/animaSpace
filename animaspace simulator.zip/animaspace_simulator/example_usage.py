"""
AnimaSpace Simulator - Comprehensive Example Usage
==================================================

This script demonstrates the complete pipeline:
  1. Define physical systems (media, cells, transducers)
  2. Calculate acoustic fields and radiation pressure
  3. Model droplet formation
  4. Simulate gas-phase transit (fast)
  5. Simulate liquid-phase transit (controlled)
  6. Tissue assembly coordination

Run this to see full traced calculations for AnimaSpace physics.

Execution: python -m animaspace_simulator.example_usage
"""

import logging
import numpy as np

# Configure logging to show all details
logging.basicConfig(
    level=logging.INFO,
    format='%(name)s - %(levelname)s: %(message)s'
)

from .core_physics import (
    PhysicsConstants,
    create_water_20c,
    create_air_20c,
    create_culture_medium_37c,
    create_generic_mammalian_cell,
)

from .acoustic import (
    AcousticTransducer,
    PMUTArray,
    AcousticRadiationPressure,
    AcousticStreaming,
    create_linear_array_1d,
    create_circular_array_2d,
)

from .fluids import StokesFluid, DragCalculator
from .droplet import DropletFormation, SurfaceTension, LaplacePressure
from .transit import TransitSimulator, GasPhaseTransit, LiquidPhaseTransit
from .assembly import TissueAssembly, CellDeposition


def print_section(title: str):
    """Print a formatted section header."""
    print("\n" + "="*70)
    print(f"  {title}")
    print("="*70 + "\n")


def example_1_physical_constants():
    """Example 1: Physical constants and material properties."""
    print_section("Example 1: Physical Constants & Material Properties")
    
    print("Core Physical Constants:")
    print(f"  Boltzmann constant (k_B): {PhysicsConstants.K_B:.3e} J/K")
    print(f"  Speed of sound (water, 20°C): {PhysicsConstants.C_SOUND_WATER_20C} m/s")
    print(f"  Speed of sound (air, 20°C): {PhysicsConstants.C_SOUND_AIR_20C} m/s")
    print(f"  Acoustic impedance (water): {PhysicsConstants.Z_WATER:.2e} kg/(m²·s)")
    print(f"  Acoustic impedance (air): {PhysicsConstants.Z_AIR:.2e} kg/(m²·s)")
    
    print("\n" + "-"*70)
    print("Water Properties (20°C, 1 atm):")
    print("-"*70)
    water_20c = create_water_20c()
    print(water_20c)
    
    print("-"*70)
    print("Air Properties (20°C, 1 atm):")
    print("-"*70)
    air_20c = create_air_20c()
    print(air_20c)
    
    print("-"*70)
    print("Culture Medium (37°C, body temperature):")
    print("-"*70)
    media_37c = create_culture_medium_37c()
    print(media_37c)


def example_2_cell_properties():
    """Example 2: Cell properties and acoustic contrast."""
    print_section("Example 2: Cell Properties & Acoustic Contrast")
    
    cell = create_generic_mammalian_cell()
    print(cell)
    
    # Acoustic contrast in different media
    media_list = [create_water_20c(), create_air_20c(), create_culture_medium_37c()]
    
    print("\nAcoustic Contrast (γ) in different media:")
    print("-"*70)
    for medium in media_list:
        cell.update_acoustic_contrast(medium.density_kg_m3)
        print(f"  In {medium.name:20s}: γ = {cell.acoustic_contrast:+.4f}")
    
    print("\nTerminal velocity under gravity:")
    print("-"*70)
    for medium in media_list:
        v_term = cell.terminal_velocity_stokes(medium)
        print(f"  In {medium.name:20s}: v_term = {v_term:.3e} m/s")


def example_3_acoustic_transducers():
    """Example 3: Acoustic transducer configuration and fields."""
    print_section("Example 3: Acoustic Transducers & Field Calculations")
    
    # Single transducer
    print("Single PMUT Element:")
    print("-"*70)
    transducer = AcousticTransducer(
        frequency_hz=1e6,  # 1 MHz
        power_w=1.0,
        efficiency=0.6,
        diameter_m=1e-3,  # 1 mm diameter
    )
    
    water = create_water_20c()
    air = create_air_20c()
    
    print(f"  Frequency: {transducer.frequency_hz/1e6:.1f} MHz")
    print(f"  Electrical power: {transducer.power_w:.2f} W")
    print(f"  Acoustic power (60% efficiency): {transducer.acoustic_power_w:.2f} W")
    print(f"  Radiating area: {transducer.area_m2:.3e} m²")
    print(f"  Acoustic intensity: {transducer.acoustic_intensity_w_m2:.2e} W/m²")
    
    print("\nAcoustic Properties in Water:")
    print("-"*70)
    P_water = transducer.peak_pressure(water)
    wavelength_water = transducer.wavelength(water)
    print(f"  Peak pressure: {P_water:.2e} Pa ({P_water/1e5:.2f} bar)")
    print(f"  Wavelength: {wavelength_water*1e3:.3f} mm")
    print(f"  Pressure at 1 mm distance: {transducer.pressure_at_distance(1e-3, water):.2e} Pa")
    
    print("\nAcoustic Properties in Air:")
    print("-"*70)
    P_air = transducer.peak_pressure(air)
    wavelength_air = transducer.wavelength(air)
    print(f"  Peak pressure: {P_air:.2e} Pa")
    print(f"  Wavelength: {wavelength_air*1e2:.3f} cm")
    print(f"  Wavelength ratio (water/air): {wavelength_water/wavelength_air:.3f}")


def example_4_acoustic_arrays():
    """Example 4: Phased arrays and beam steering."""
    print_section("Example 4: Phased Arrays & Beam Steering")
    
    # Create linear array
    print("1D Linear Array (8 elements):")
    print("-"*70)
    linear_array = create_linear_array_1d(
        num_elements=8,
        spacing_m=1e-3,
        frequency_hz=1e6,
        power_per_element_w=0.5,
    )
    
    print(f"  Total elements: {linear_array.total_elements}")
    print(f"  Total acoustic power: {linear_array.total_acoustic_power():.2f} W")
    
    water = create_water_20c()
    print(f"  Average peak pressure: {linear_array.average_peak_pressure(water):.2e} Pa")
    
    print("\nApplying plane-wave pattern (all in phase):")
    linear_array.set_phased_pattern('plane_wave')
    
    print("\nApplying focused pattern (focal distance = 10 mm):")
    linear_array.set_phased_pattern('focused', focal_distance_m=0.01)
    
    print("\nApplying vortex pattern (toroidal formation):")
    linear_array.set_phased_pattern('vortex')
    
    # Create circular array
    print("\n2D Circular Array (16 elements):")
    print("-"*70)
    circular_array = create_circular_array_2d(
        num_elements=16,
        array_radius_m=5e-3,
        frequency_hz=1e6,
        power_per_element_w=0.5,
    )
    
    print(f"  Total elements: {circular_array.total_elements}")
    print(f"  Total acoustic power: {circular_array.total_acoustic_power():.2f} W")
    print(f"  Array radius: {5e-3*1e3:.1f} mm")


def example_5_radiation_pressure():
    """Example 5: Acoustic radiation pressure and forces."""
    print_section("Example 5: Acoustic Radiation Pressure & Forces")
    
    water = create_water_20c()
    air = create_air_20c()
    
    # Create transducer
    transducer = AcousticTransducer(
        frequency_hz=1e6,
        power_w=1.0,
        efficiency=0.6,
    )
    
    P_water = transducer.peak_pressure(water)
    P_air = transducer.peak_pressure(air)
    
    print("Acoustic Radiation Pressure (P = I/c = P²/(2ρc²)):")
    print("-"*70)
    
    P_rad_water = AcousticRadiationPressure.radiation_pressure_from_pressure(P_water, water)
    P_rad_air = AcousticRadiationPressure.radiation_pressure_from_pressure(P_air, air)
    
    print(f"  In water: {P_rad_water:.2e} Pa ({P_rad_water/1000:.3f} kPa)")
    print(f"  In air: {P_rad_air:.2e} Pa ({P_rad_air/1000:.3f} kPa)")
    print(f"  Ratio (water/air): {P_rad_water/P_rad_air:.2f}×")
    
    # Acoustic force on cell
    print("\nAcoustic Radiation Force on Cell:")
    print("-"*70)
    
    cell = create_generic_mammalian_cell()
    
    cell.update_acoustic_contrast(water.density_kg_m3)
    F_cell_water = AcousticRadiationPressure.acoustic_force_on_particle(
        cell, water, P_water, transducer.frequency_hz
    )
    
    cell.update_acoustic_contrast(air.density_kg_m3)
    F_cell_air = AcousticRadiationPressure.acoustic_force_on_particle(
        cell, air, P_air, transducer.frequency_hz
    )
    
    print(f"  Force on cell in water: {F_cell_water:.2e} N")
    print(f"  Force on cell in air: {F_cell_air:.2e} N")
    print(f"  Ratio (water/air): {F_cell_water/F_cell_air:.2f}×")


def example_6_acoustic_streaming():
    """Example 6: Acoustic streaming and vortex formation."""
    print_section("Example 6: Acoustic Streaming & Vortex Formation")
    
    water = create_water_20c()
    air = create_air_20c()
    
    transducer = AcousticTransducer(frequency_hz=1e6, power_w=1.0, efficiency=0.6)
    
    P_water = transducer.peak_pressure(water)
    P_air = transducer.peak_pressure(air)
    
    print("Acoustic Streaming Velocity (v_stream ∝ P²/(ρ·η·ω)):")
    print("-"*70)
    
    v_stream_water = AcousticStreaming.streaming_velocity_estimate(P_water, water, transducer.frequency_hz)
    v_stream_air = AcousticStreaming.streaming_velocity_estimate(P_air, air, transducer.frequency_hz)
    
    print(f"  In water: {v_stream_water:.3e} m/s")
    print(f"  In air: {v_stream_air:.3e} m/s")
    print(f"  Ratio (water/air): {v_stream_water/v_stream_air:.3e}×")
    
    print("\nToroidal Vortex Formation:")
    print("-"*70)
    
    r_toroid_water = AcousticStreaming.toroidal_vortex_radius(transducer.frequency_hz, water)
    r_toroid_air = AcousticStreaming.toroidal_vortex_radius(transducer.frequency_hz, air)
    
    print(f"  In water (wavelength-scaled): {r_toroid_water*1e6:.1f} μm radius")
    print(f"  In air (wavelength-scaled): {r_toroid_air*1e3:.2f} mm radius")


def example_7_drag_forces():
    """Example 7: Drag forces and Reynolds numbers."""
    print_section("Example 7: Drag Forces & Reynolds Numbers")
    
    water = create_water_20c()
    air = create_air_20c()
    
    cell = create_generic_mammalian_cell()
    droplet_radius = 100e-6  # 100 μm
    
    print("Cell/Droplet Specifications:")
    print("-"*70)
    print(f"  Radius: {droplet_radius*1e6:.1f} μm")
    print(f"  Characteristic length (diameter): {2*droplet_radius*1e6:.1f} μm")
    
    velocities = [0.01, 0.1, 1.0, 10.0]  # m/s
    
    print("\nStokes Drag in Water:")
    print("-"*70)
    print(f"{'Velocity (m/s)':>15} {'Re':>12} {'Drag (N)':>15} {'Regime':>30}")
    print("-"*70)
    
    for v in velocities:
        F_drag, metadata = DragCalculator.total_drag(droplet_radius, v, water)
        Re = metadata['Re']
        regime = metadata['regime']
        print(f"{v:>15.2e} {Re:>12.3e} {F_drag:>15.3e} {regime:>30}")
    
    print("\nStokes Drag in Air (same velocities):")
    print("-"*70)
    print(f"{'Velocity (m/s)':>15} {'Re':>12} {'Drag (N)':>15} {'Regime':>30}")
    print("-"*70)
    
    for v in velocities:
        F_drag, metadata = DragCalculator.total_drag(droplet_radius, v, air)
        Re = metadata['Re']
        regime = metadata['regime']
        print(f"{v:>15.2e} {Re:>12.3e} {F_drag:>15.3e} {regime:>30}")
    
    print("\nDrag Force Ratio (water/air) at same velocity:")
    print("-"*70)
    for v in velocities:
        F_water, _ = DragCalculator.total_drag(droplet_radius, v, water)
        F_air, _ = DragCalculator.total_drag(droplet_radius, v, air)
        ratio = F_water / F_air if F_air > 0 else np.inf
        print(f"  At {v} m/s: {ratio:.1f}× higher drag in water")


def example_8_droplet_formation():
    """Example 8: Droplet formation and surface tension."""
    print_section("Example 8: Droplet Formation & Surface Tension")
    
    water = create_water_20c()
    cell = create_generic_mammalian_cell()
    
    droplet = DropletFormation(water, cell)
    
    print(droplet)
    
    # Surface tension
    print("Surface Tension Analysis:")
    print("-"*70)
    sigma = SurfaceTension.water_air_surface_tension(temperature_c=20.0)
    print(f"  Water-air (20°C): {sigma:.4f} N/m")
    
    sigma_37 = SurfaceTension.water_air_surface_tension(temperature_c=37.0)
    print(f"  Water-air (37°C): {sigma_37:.4f} N/m")
    
    sigma_medium = SurfaceTension.interfacial_tension_medium_air(temperature_c=37.0)
    print(f"  Culture medium-air (37°C): {sigma_medium:.4f} N/m")
    
    # Laplace pressure
    print("\nLaplace Pressure (ΔP = 2σ/r):")
    print("-"*70)
    
    radii_um = [10, 50, 100, 500]
    print(f"{'Radius (μm)':>15} {'ΔP (Pa)':>15} {'ΔP (kPa)':>15}")
    print("-"*70)
    
    for r_um in radii_um:
        r_m = r_um * 1e-6
        delta_p = LaplacePressure.pressure_jump_sphere(r_m, sigma)
        print(f"{r_um:>15} {delta_p:>15.2e} {delta_p/1000:>15.3f}")


def example_9_transit_gas_phase():
    """Example 9: Gas-phase transit simulation."""
    print_section("Example 9: Gas-Phase Transit (WRM → Bio-reactor)")
    
    air = create_air_20c()
    transducer = AcousticTransducer(frequency_hz=1e6, power_w=1.0, efficiency=0.6)
    
    water = create_water_20c()
    cell = create_generic_mammalian_cell()
    droplet = DropletFormation(water, cell)
    
    # Simulate
    gas_transit = GasPhaseTransit(droplet, air, transducer)
    
    droplet_radius = 100e-6  # 100 μm
    
    print(f"Droplet radius: {droplet_radius*1e6:.1f} μm")
    print(f"\nCalculated parameters:")
    print("-"*70)
    
    v_term = gas_transit.velocity_terminal_gas_phase(droplet_radius)
    tau = gas_transit.time_to_terminal_velocity_gas(droplet_radius)
    
    print(f"  Terminal velocity: {v_term:.3f} m/s")
    print(f"  Time to terminal velocity: {tau:.3e} s")
    print(f"  Relaxation distance: {v_term * tau:.3e} m")
    
    # Simulate full transit
    print("\nSimulating 0.1 m transit (WRM → Bio-reactor):")
    print("-"*70)
    
    start = (0.0, 0.0, 0.0)
    end = (0.1, 0.0, 0.0)
    
    trajectory = gas_transit.simulate_trajectory(start, end, droplet_radius)
    
    print(f"\nResults:")
    print(f"  Total distance: {trajectory.distance_total_m:.4f} m")
    print(f"  Total time: {trajectory.time_total_s:.3e} s")
    print(f"  Average speed: {trajectory.distance_total_m/trajectory.time_total_s:.3f} m/s")


def example_10_tissue_assembly():
    """Example 10: Tissue assembly and cell placement."""
    print_section("Example 10: Tissue Assembly & Cell Placement")
    
    # Create tissue structure
    tissue = TissueAssembly(tissue_type="Simple 3D Scaffold")
    
    # Add cells in a simple 3D lattice
    print("Building tissue scaffold (5×5×5 cell lattice):")
    print("-"*70)
    
    cell_spacing_um = 20  # 20 μm between cells
    
    for x in range(5):
        for y in range(5):
            for z in range(5):
                dep = CellDeposition(
                    cell_type="fibroblast",
                    position_x_um=x * cell_spacing_um,
                    position_y_um=y * cell_spacing_um,
                    position_z_um=z * cell_spacing_um,
                    deposition_time_s=(x + y*5 + z*25) * 0.5,  # Sequential timing
                    viability_score=0.95,
                )
                tissue.add_deposition(dep)
    
    print(f"  Total cells: {tissue.total_cells()}")
    print(f"  Tissue dimensions: {4*cell_spacing_um} × {4*cell_spacing_um} × {4*cell_spacing_um} μm")
    print(f"  Cell type breakdown: {tissue.cells_by_type()}")
    
    print("\nDeposition schedule (first 10 events):")
    print("-"*70)
    print(f"{'Cell #':>8} {'Type':>15} {'Position (μm)':>30} {'Time (s)':>10} {'Viable':>6}")
    print("-"*70)
    
    for i, dep in enumerate(tissue.depositions[:10]):
        pos = f"({dep.position_x_um:.0f}, {dep.position_y_um:.0f}, {dep.position_z_um:.0f})"
        viable = "✓" if dep.is_viable() else "✗"
        print(f"{i+1:>8} {'fibroblast':>15} {pos:>30} {dep.deposition_time_s:>10.2f} {viable:>6}")


def main():
    """Run all examples."""
    print("\n")
    print("╔" + "="*68 + "╗")
    print("║" + " "*68 + "║")
    print("║" + "  AnimaSpace Physics Simulator - Comprehensive Examples".center(68) + "║")
    print("║" + "  Fully-Traceable Calculations for Microgravity Bio-Manufacturing".center(68) + "║")
    print("║" + " "*68 + "║")
    print("╚" + "="*68 + "╝")
    print()
    
    # Run all examples
    example_1_physical_constants()
    example_2_cell_properties()
    example_3_acoustic_transducers()
    example_4_acoustic_arrays()
    example_5_radiation_pressure()
    example_6_acoustic_streaming()
    example_7_drag_forces()
    example_8_droplet_formation()
    example_9_transit_gas_phase()
    example_10_tissue_assembly()
    
    print_section("All Examples Complete")
    print("Run this module again to re-execute all calculations with full tracing.")
    print()


if __name__ == "__main__":
    main()
